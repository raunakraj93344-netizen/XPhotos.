import { Platform, Share } from 'react-native';
import type { Photo } from '@/types';

export function formatCount(value: number): string {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
  return `${value}`;
}

export function formatBytes(bytes: number): string {
  if (bytes <= 0) return '0 MB';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function estimateSize(photo: Photo): number {
  return Math.round(photo.width * photo.height * 0.62);
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
}

export function formatShortDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function relativeDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 86400000);
  if (diff <= 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7) return `${diff} days ago`;
  if (diff < 30) return `${Math.floor(diff / 7)} weeks ago`;
  if (diff < 365) return `${Math.floor(diff / 30)} months ago`;
  const years = Math.floor(diff / 365);
  return years === 1 ? '1 year ago' : `${years} years ago`;
}

export function groupLabel(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 86400000);
  if (diff <= 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7) return 'This week';
  if (diff < 30) return 'This month';
  return date.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
}

export function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');
}

export function searchPhotos<T extends { title: string; tags: string[]; location: string; photographer: string; category: string }>(
  items: T[],
  query: string
): T[] {
  const q = query.trim().toLowerCase();
  if (!q) return items;
  const terms = q.split(/\s+/).filter(Boolean);
  const haystackOf = (photo: T) =>
    `${photo.title} ${photo.tags.join(' ')} ${photo.location} ${photo.photographer} ${photo.category}`.toLowerCase();
  const matchesTerm = (haystack: string, term: string) => {
    if (haystack.includes(term)) return true;
    if (term.length > 3 && term.endsWith('s') && haystack.includes(term.slice(0, -1))) return true;
    return false;
  };
  const exact = items.filter((photo) => {
    const haystack = haystackOf(photo);
    return terms.every((term) => matchesTerm(haystack, term));
  });
  if (exact.length > 0) return exact;
  return items.filter((photo) => {
    const haystack = haystackOf(photo);
    return terms.some((term) => matchesTerm(haystack, term));
  });
}

export async function sharePhoto(photo: Photo): Promise<void> {
  const message = `${photo.title} — by ${photo.photographer} on XPhotos`;
  try {
    if (Platform.OS === 'web') {
      const nav = typeof navigator !== 'undefined' ? (navigator as Navigator & { share?: (data: { title?: string; text?: string; url?: string }) => Promise<void> }) : undefined;
      if (nav?.share) {
        await nav.share({ title: photo.title, text: message, url: photo.uri });
        return;
      }
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        await navigator.clipboard.writeText(`${message} ${photo.uri}`);
      }
      return;
    }
    await Share.share({ message: `${message} ${photo.uri}` });
  } catch {
    return;
  }
}

export async function downloadPhoto(photo: Photo): Promise<void> {
  if (Platform.OS === 'web' && typeof document !== 'undefined') {
    const link = document.createElement('a');
    link.href = photo.uri;
    link.download = `${photo.title.replace(/\s+/g, '-').toLowerCase()}.jpg`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return;
  }
  await sharePhoto(photo);
}
