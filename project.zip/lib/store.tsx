import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { photos as basePhotos, curatedAlbums } from '@/data/photos';
import { palettes, type Gradient, type Palette } from '@/constants/theme';
import type { Photo, Settings, UserAlbum } from '@/types';
import { estimateSize } from '@/lib/utils';

const STORAGE_KEY = 'xphotos:state:v1';

const defaultSettings: Settings = {
  themeMode: 'dark',
  density: 'comfortable',
  sort: 'newest',
  autoplay: true,
  showMeta: true,
};

type PersistedState = {
  favorites: string[];
  userAlbums: UserAlbum[];
  customPhotos: Photo[];
  hiddenIds: string[];
  recentSearches: string[];
  settings: Settings;
};

type GalleryStats = {
  totalPhotos: number;
  favorites: number;
  albums: number;
  storageBytes: number;
  categoryCounts: Array<{ category: string; count: number }>;
};

export type ResolvedAlbum = {
  id: string;
  title: string;
  subtitle: string;
  emoji: string;
  gradient: Gradient;
  photos: Photo[];
  photoIds: string[];
  isUser: boolean;
  isSmart: boolean;
};

type GalleryContextValue = {
  photos: Photo[];
  favorites: string[];
  userAlbums: UserAlbum[];
  recentSearches: string[];
  settings: Settings;
  hydrated: boolean;
  palette: Palette;
  stats: GalleryStats;
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
  getPhoto: (id: string | undefined) => Photo | undefined;
  createAlbum: (title: string, emoji: string) => string;
  deleteAlbum: (id: string) => void;
  renameAlbum: (id: string, title: string) => void;
  addPhotosToAlbum: (albumId: string, photoIds: string[]) => void;
  removePhotosFromAlbum: (albumId: string, photoIds: string[]) => void;
  addPhoto: (uri: string) => Photo;
  deletePhotos: (ids: string[]) => void;
  recordSearch: (query: string) => void;
  clearRecentSearches: () => void;
  updateSettings: (patch: Partial<Settings>) => void;
  resetData: () => void;
  resolveAlbum: (albumId: string) => ResolvedAlbum | undefined;
  curated: typeof curatedAlbums;
};

const GalleryContext = createContext<GalleryContextValue | null>(null);

const emptyPersisted: PersistedState = {
  favorites: [],
  userAlbums: [],
  customPhotos: [],
  hiddenIds: [],
  recentSearches: [],
  settings: defaultSettings,
};

const emojiCycle = ['📸', '🌟', '🌊', '🏔️', '🍜', '🐾', '🎨', '🚗'];

export function GalleryProvider({ children }: { children: ReactNode }) {
  const systemScheme = useColorScheme();
  const [persisted, setPersisted] = useState<PersistedState>(emptyPersisted);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!mounted) return;
        if (raw) {
          const parsed = JSON.parse(raw) as Partial<PersistedState>;
          setPersisted({
            favorites: parsed.favorites ?? [],
            userAlbums: parsed.userAlbums ?? [],
            customPhotos: parsed.customPhotos ?? [],
            hiddenIds: parsed.hiddenIds ?? [],
            recentSearches: parsed.recentSearches ?? [],
            settings: { ...defaultSettings, ...(parsed.settings ?? {}) },
          });
        }
      })
      .catch(() => undefined)
      .finally(() => {
        if (mounted) setHydrated(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(persisted)).catch(() => undefined);
  }, [persisted, hydrated]);

  const photos = useMemo(() => {
    const hidden = new Set(persisted.hiddenIds);
    const visibleBase = basePhotos.filter((p) => !hidden.has(p.id));
    return [...persisted.customPhotos, ...visibleBase].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }, [persisted.customPhotos, persisted.hiddenIds]);

  const palette = useMemo(() => {
    const mode =
      persisted.settings.themeMode === 'system'
        ? systemScheme === 'light'
          ? 'light'
          : 'dark'
        : persisted.settings.themeMode;
    return palettes[mode];
  }, [persisted.settings.themeMode, systemScheme]);

  const isFavorite = useCallback(
    (id: string) => persisted.favorites.includes(id),
    [persisted.favorites]
  );

  const toggleFavorite = useCallback((id: string) => {
    setPersisted((prev) => {
      const exists = prev.favorites.includes(id);
      return {
        ...prev,
        favorites: exists ? prev.favorites.filter((f) => f !== id) : [id, ...prev.favorites],
      };
    });
  }, []);

  const getPhoto = useCallback((id: string | undefined) => photos.find((p) => p.id === id), [photos]);

  const createAlbum = useCallback((title: string, emoji: string) => {
    const id = `album-${Date.now()}`;
    const album: UserAlbum = {
      id,
      title: title.trim() || 'Untitled album',
      emoji: emoji || emojiCycle[Math.floor(Math.random() * emojiCycle.length)],
      gradient: 'violet',
      photoIds: [],
      createdAt: new Date().toISOString(),
    };
    setPersisted((prev) => ({ ...prev, userAlbums: [album, ...prev.userAlbums] }));
    return id;
  }, []);

  const deleteAlbum = useCallback((id: string) => {
    setPersisted((prev) => ({ ...prev, userAlbums: prev.userAlbums.filter((a) => a.id !== id) }));
  }, []);

  const renameAlbum = useCallback((id: string, title: string) => {
    setPersisted((prev) => ({
      ...prev,
      userAlbums: prev.userAlbums.map((a) =>
        a.id === id ? { ...a, title: title.trim() || a.title } : a
      ),
    }));
  }, []);

  const addPhotosToAlbum = useCallback((albumId: string, photoIds: string[]) => {
    setPersisted((prev) => ({
      ...prev,
      userAlbums: prev.userAlbums.map((a) =>
        a.id === albumId
          ? { ...a, photoIds: Array.from(new Set([...a.photoIds, ...photoIds])) }
          : a
      ),
    }));
  }, []);

  const removePhotosFromAlbum = useCallback((albumId: string, photoIds: string[]) => {
    const remove = new Set(photoIds);
    setPersisted((prev) => ({
      ...prev,
      userAlbums: prev.userAlbums.map((a) =>
        a.id === albumId ? { ...a, photoIds: a.photoIds.filter((pid) => !remove.has(pid)) } : a
      ),
    }));
  }, []);

  const addPhoto = useCallback((uri: string) => {
    const photo: Photo = {
      id: `c-${Date.now()}`,
      uri,
      thumb: uri,
      width: 1080,
      height: 1440,
      title: 'New Capture',
      category: 'Camera',
      tags: ['camera', 'capture', 'recent', 'personal'],
      location: 'Captured on device',
      photographer: 'You',
      date: new Date().toISOString(),
      likes: 0,
      views: 0,
      camera: 'XPhotos Camera',
      lens: 'Wide 26mm',
      iso: 120,
      aperture: 'f/1.8',
      shutter: '1/120s',
      focalLength: '26mm',
      isCustom: true,
    };
    setPersisted((prev) => ({ ...prev, customPhotos: [photo, ...prev.customPhotos] }));
    return photo;
  }, []);

  const deletePhotos = useCallback((ids: string[]) => {
    const remove = new Set(ids);
    setPersisted((prev) => ({
      ...prev,
      favorites: prev.favorites.filter((id) => !remove.has(id)),
      customPhotos: prev.customPhotos.filter((p) => !remove.has(p.id)),
      hiddenIds: Array.from(
        new Set([
          ...prev.hiddenIds,
          ...ids.filter((id) => !prev.customPhotos.some((p) => p.id === id)),
        ])
      ),
      userAlbums: prev.userAlbums.map((a) => ({
        ...a,
        photoIds: a.photoIds.filter((id) => !remove.has(id)),
      })),
    }));
  }, []);

  const recordSearch = useCallback((query: string) => {
    const q = query.trim();
    if (!q) return;
    setPersisted((prev) => ({
      ...prev,
      recentSearches: [q, ...prev.recentSearches.filter((s) => s.toLowerCase() !== q.toLowerCase())].slice(0, 8),
    }));
  }, []);

  const clearRecentSearches = useCallback(() => {
    setPersisted((prev) => ({ ...prev, recentSearches: [] }));
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setPersisted((prev) => ({ ...prev, settings: { ...prev.settings, ...patch } }));
  }, []);

  const resetData = useCallback(() => {
    setPersisted(emptyPersisted);
  }, []);

  const stats = useMemo<GalleryStats>(() => {
    const counts = new Map<string, number>();
    let storage = 0;
    photos.forEach((p) => {
      counts.set(p.category, (counts.get(p.category) ?? 0) + 1);
      storage += estimateSize(p);
    });
    return {
      totalPhotos: photos.length,
      favorites: persisted.favorites.length,
      albums: persisted.userAlbums.length,
      storageBytes: storage,
      categoryCounts: Array.from(counts.entries())
        .map(([category, count]) => ({ category, count }))
        .sort((a, b) => b.count - a.count),
    };
  }, [photos, persisted.favorites.length, persisted.userAlbums.length]);

  const resolveAlbum = useCallback(
    (albumId: string): ResolvedAlbum | undefined => {
      if (albumId === 'favorites') {
        const favSet = new Set(persisted.favorites);
        return {
          id: 'favorites',
          title: 'Favorites',
          subtitle: 'Your most-loved shots',
          emoji: '❤️',
          gradient: ['#FF5C8A', '#FF8A5C'],
          photos: photos.filter((p) => favSet.has(p.id)),
          photoIds: photos.filter((p) => favSet.has(p.id)).map((p) => p.id),
          isUser: false,
          isSmart: true,
        };
      }
      if (albumId === 'recent') {
        return {
          id: 'recent',
          title: 'Recently Added',
          subtitle: 'Fresh from the last 30 days',
          emoji: '🕒',
          gradient: ['#2E7BFF', '#21D4C4'],
          photos: photos.slice(0, 30),
          photoIds: photos.slice(0, 30).map((p) => p.id),
          isUser: false,
          isSmart: true,
        };
      }
      if (albumId === 'camera') {
        return {
          id: 'camera',
          title: 'Camera Roll',
          subtitle: 'Captured with XPhotos',
          emoji: '📷',
          gradient: ['#2B2B38', '#5C5C72'],
          photos: photos.filter((p) => p.isCustom),
          photoIds: photos.filter((p) => p.isCustom).map((p) => p.id),
          isUser: false,
          isSmart: true,
        };
      }
      if (albumId === 'all') {
        return {
          id: 'all',
          title: 'All Photos',
          subtitle: 'Everything in your library',
          emoji: '🗂️',
          gradient: ['#7C5CFF', '#C05CFF'],
          photos,
          photoIds: photos.map((p) => p.id),
          isUser: false,
          isSmart: true,
        };
      }
      const user = persisted.userAlbums.find((a) => a.id === albumId);
      if (user) {
        const set = new Set(user.photoIds);
        return {
          id: user.id,
          title: user.title,
          subtitle: `${user.photoIds.length} ${user.photoIds.length === 1 ? 'photo' : 'photos'}`,
          emoji: user.emoji,
          gradient: ['#7C5CFF', '#C05CFF'],
          photos: photos.filter((p) => set.has(p.id)),
          photoIds: user.photoIds,
          isUser: true,
          isSmart: false,
        };
      }
      return undefined;
    },
    [photos, persisted.favorites, persisted.userAlbums]
  );

  const value = useMemo<GalleryContextValue>(
    () => ({
      photos,
      favorites: persisted.favorites,
      userAlbums: persisted.userAlbums,
      recentSearches: persisted.recentSearches,
      settings: persisted.settings,
      hydrated,
      palette,
      stats,
      isFavorite,
      toggleFavorite,
      getPhoto,
      createAlbum,
      deleteAlbum,
      renameAlbum,
      addPhotosToAlbum,
      removePhotosFromAlbum,
      addPhoto,
      deletePhotos,
      recordSearch,
      clearRecentSearches,
      updateSettings,
      resetData,
      resolveAlbum,
      curated: curatedAlbums,
    }),
    [
      photos,
      persisted.favorites,
      persisted.userAlbums,
      persisted.recentSearches,
      persisted.settings,
      hydrated,
      palette,
      stats,
      isFavorite,
      toggleFavorite,
      getPhoto,
      createAlbum,
      deleteAlbum,
      renameAlbum,
      addPhotosToAlbum,
      removePhotosFromAlbum,
      addPhoto,
      deletePhotos,
      recordSearch,
      clearRecentSearches,
      updateSettings,
      resetData,
      resolveAlbum,
    ]
  );

  return <GalleryContext.Provider value={value}>{children}</GalleryContext.Provider>;
}

export function useGallery(): GalleryContextValue {
  const ctx = useContext(GalleryContext);
  if (!ctx) throw new Error('useGallery must be used inside GalleryProvider');
  return ctx;
}

export function usePalette(): Palette {
  return useGallery().palette;
}
