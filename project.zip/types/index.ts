import type { GradientKey } from '@/constants/theme';

export type Category =
  | 'Nature'
  | 'Travel'
  | 'City'
  | 'Food'
  | 'Animals'
  | 'People'
  | 'Abstract'
  | 'Cars'
  | 'Fashion'
  | 'Camera';

export type Photo = {
  id: string;
  uri: string;
  thumb: string;
  width: number;
  height: number;
  title: string;
  category: Category;
  tags: string[];
  location: string;
  photographer: string;
  date: string;
  likes: number;
  views: number;
  camera: string;
  lens: string;
  iso: number;
  aperture: string;
  shutter: string;
  focalLength: string;
  isCustom?: boolean;
};

export type UserAlbum = {
  id: string;
  title: string;
  emoji: string;
  gradient: GradientKey;
  photoIds: string[];
  createdAt: string;
};

export type CuratedAlbum = {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  gradient: GradientKey;
  emoji: string;
  photoIds: string[];
  tag: string;
};

export type Story = {
  id: string;
  title: string;
  coverId: string;
  albumId: string;
  gradient: GradientKey;
};

export type Settings = {
  themeMode: 'system' | 'light' | 'dark';
  density: 'comfortable' | 'compact';
  sort: 'newest' | 'oldest' | 'az' | 'category';
  autoplay: boolean;
  showMeta: boolean;
};

export type PhotoFilter = 'all' | 'favorites' | 'recent';

export type ViewMode = 'masonry' | 'grid';
