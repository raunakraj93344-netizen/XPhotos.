import type { Category, CuratedAlbum, Photo, Story } from '@/types';

const pexels = (id: number, w: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}`;

type Seed = [id: number, title: string, category: Category, location: string, photographer: string];

const seeds: Seed[] = [
  [417074, 'Alpine Stillness', 'Nature', 'Banff, Canada', 'Elena Marsh'],
  [167699, 'Misty Pines', 'Nature', 'Black Forest, Germany', 'Kai Nakamura'],
  [268533, 'Golden Fields', 'Nature', 'Tuscany, Italy', 'Sofia Lindqvist'],
  [355465, 'Wild Coast', 'Nature', 'Big Sur, USA', 'Elena Marsh'],
  [210186, 'Forest Whispers', 'Nature', 'Olympic Park, USA', 'Kai Nakamura'],
  [1001671, 'Desert Bloom', 'Nature', 'Atacama, Chile', 'Sofia Lindqvist'],
  [1470405, 'Frozen Lake', 'Nature', 'Jasper, Canada', 'Elena Marsh'],
  [325185, 'Sunlit Canyon', 'Nature', 'Utah, USA', 'Kai Nakamura'],
  [1366909, 'Emerald Valley', 'Nature', 'Faroe Islands', 'Sofia Lindqvist'],

  [386009, 'Santorini Blues', 'Travel', 'Oia, Greece', 'Marco Duarte'],
  [1323550, 'Backpack Diaries', 'Travel', 'Kathmandu, Nepal', 'Aisha Rahman'],
  [358482, 'Road to Anywhere', 'Travel', 'Route 66, USA', 'Liam O\'Connor'],
  [672358, 'Harbor Lights', 'Travel', 'Bergen, Norway', 'Marco Duarte'],
  [248797, 'Island Hop', 'Travel', 'Palawan, Philippines', 'Aisha Rahman'],
  [1234859, 'Passport Stamps', 'Travel', 'Marrakech, Morocco', 'Liam O\'Connor'],
  [247431, 'Old Town Charm', 'Travel', 'Prague, Czechia', 'Marco Duarte'],
  [1285625, 'Northern Escape', 'Travel', 'Tromsø, Norway', 'Aisha Rahman'],
  [3155666, 'Train Window', 'Travel', 'Kyoto, Japan', 'Liam O\'Connor'],

  [466685, 'Neon Nights', 'City', 'Tokyo, Japan', 'Noah Bennett'],
  [1105766, 'Skyline Pulse', 'City', 'New York, USA', 'Yuki Tanaka'],
  [220887, 'Rainy Reflections', 'City', 'London, UK', 'Priya Nair'],
  [378570, 'Concrete Jungle', 'City', 'Chicago, USA', 'Noah Bennett'],
  [358443, 'Bridge & Fog', 'City', 'San Francisco, USA', 'Yuki Tanaka'],
  [325193, 'Downtown Dusk', 'City', 'Dubai, UAE', 'Priya Nair'],
  [373912, 'Rooftop View', 'City', 'Barcelona, Spain', 'Noah Bennett'],
  [206359, 'Subway Stories', 'City', 'Seoul, South Korea', 'Yuki Tanaka'],

  [302899, 'Morning Brew', 'Food', 'Melbourne, Australia', 'Isabella Rossi'],
  [1640777, 'Fresh Market', 'Food', 'Provence, France', 'Diego Alvarez'],
  [70497, 'Wood-Fired', 'Food', 'Naples, Italy', 'Mina Park'],
  [1099680, 'Berry Bowl', 'Food', 'Lisbon, Portugal', 'Isabella Rossi'],
  [461198, 'Street Tacos', 'Food', 'Mexico City, Mexico', 'Diego Alvarez'],
  [958545, 'Pasta Night', 'Food', 'Bologna, Italy', 'Mina Park'],
  [262978, 'Garden Salad', 'Food', 'Copenhagen, Denmark', 'Isabella Rossi'],
  [1279330, 'Pizza Sunday', 'Food', 'Brooklyn, USA', 'Diego Alvarez'],

  [1108099, 'Loyal Companion', 'Animals', 'Boulder, USA', 'Hannah Wolf'],
  [1170986, 'Nap Time', 'Animals', 'Oslo, Norway', 'Tomás Ferreira'],
  [416160, 'Forest Fox', 'Animals', 'Hokkaido, Japan', 'Grace Chen'],
  [462358, 'Ocean Wanderer', 'Animals', 'Azores, Portugal', 'Hannah Wolf'],
  [458799, 'Feathered Friend', 'Animals', 'Costa Rica', 'Tomás Ferreira'],
  [1661179, 'Puppy Eyes', 'Animals', 'Austin, USA', 'Grace Chen'],
  [733416, 'Silent Paws', 'Animals', 'Scottish Highlands', 'Hannah Wolf'],
  [617278, 'Sunbathing', 'Animals', 'Sardinia, Italy', 'Tomás Ferreira'],

  [220453, 'Portrait in Gold', 'People', 'Marrakesh, Morocco', 'Ava Laurent'],
  [415829, 'Quiet Confidence', 'People', 'Paris, France', 'Ethan Cole'],
  [774909, 'Street Style', 'People', 'Milan, Italy', 'Nadia Haddad'],
  [1239291, 'Candid Laugh', 'People', 'Havana, Cuba', 'Ava Laurent'],
  [614810, 'Studio Light', 'People', 'Berlin, Germany', 'Ethan Cole'],
  [91227, 'Golden Hour Glow', 'People', 'Los Angeles, USA', 'Nadia Haddad'],
  [1681010, 'Motion Blur', 'People', 'Hong Kong', 'Ava Laurent'],
  [733872, 'Summer Smile', 'People', 'Bali, Indonesia', 'Ethan Cole'],

  [2901209, 'Liquid Metal', 'Abstract', 'Studio, NYC', 'Leo Voss'],
  [1103970, 'Color Field', 'Abstract', 'Studio, Berlin', 'Iris Fontaine'],
  [3075993, 'Geometric Dreams', 'Abstract', 'Studio, Tokyo', 'Omar Farouk'],
  [7130560, 'Soft Gradients', 'Abstract', 'Studio, London', 'Leo Voss'],
  [356040, 'Neon Pulse', 'Abstract', 'Studio, Seoul', 'Iris Fontaine'],
  [3621234, 'Paper Planes', 'Abstract', 'Studio, Paris', 'Omar Farouk'],
  [1032650, 'Prism', 'Abstract', 'Studio, Lisbon', 'Leo Voss'],
  [268287, 'Waves of Light', 'Abstract', 'Studio, Reykjavik', 'Iris Fontaine'],

  [170811, 'Midnight Drive', 'Cars', 'Los Angeles, USA', 'Jake Sullivan'],
  [116675, 'Classic Chrome', 'Cars', 'Monterey, USA', 'Elena Petrova'],
  [358070, 'Track Day', 'Cars', 'Silverstone, UK', 'Jake Sullivan'],
  [305070, 'City Cruiser', 'Cars', 'Tokyo, Japan', 'Elena Petrova'],
  [112460, 'Desert Roadster', 'Cars', 'Nevada, USA', 'Jake Sullivan'],
  [210019, 'Garage Queen', 'Cars', 'Detroit, USA', 'Elena Petrova'],

  [994523, 'Runway Edit', 'Fashion', 'Paris, France', 'Camille Moreau'],
  [1536619, 'Denim Days', 'Fashion', 'Amsterdam, Netherlands', 'Ravi Kapoor'],
  [2065195, 'Monochrome', 'Fashion', 'Milan, Italy', 'Camille Moreau'],
  [1926769, 'Street Luxe', 'Fashion', 'New York, USA', 'Ravi Kapoor'],
  [1755428, 'Editorial No. 4', 'Fashion', 'London, UK', 'Camille Moreau'],
  [1689731, 'Silk & Shadow', 'Fashion', 'Seoul, South Korea', 'Ravi Kapoor'],
];

const categoryTags: Record<Category, string[]> = {
  Nature: ['nature', 'landscape', 'outdoors', 'green', 'tranquil', 'wilderness', 'mountains', 'lake', 'sunset', 'sunrise', 'forest', 'hiking', 'golden'],
  Travel: ['travel', 'wanderlust', 'adventure', 'explore', 'destination', 'holiday', 'vacation', 'trip', 'beach'],
  City: ['city', 'urban', 'architecture', 'skyline', 'night', 'street', 'lights', 'neon', 'downtown', 'street photography'],
  Food: ['food', 'cuisine', 'delicious', 'restaurant', 'gourmet', 'fresh', 'coffee', 'breakfast', 'brunch', 'street', 'pizza', 'pasta', 'street food'],
  Animals: ['animals', 'wildlife', 'pets', 'cute', 'nature', 'portrait', 'dogs', 'cats'],
  People: ['people', 'portrait', 'portraits', 'lifestyle', 'candid', 'human', 'mood', 'faces', 'smile'],
  Abstract: ['abstract', 'texture', 'color', 'art', 'minimal', 'pattern', 'gradient'],
  Cars: ['cars', 'car', 'automotive', 'speed', 'drive', 'classic', 'luxury', 'road'],
  Fashion: ['fashion', 'style', 'editorial', 'portrait', 'luxury', 'design', 'outfit', 'runway'],
  Camera: ['camera', 'capture', 'recent', 'personal'],
};

const cameraBodies = ['Sony A7 IV', 'Canon EOS R5', 'Nikon Z8', 'Fujifilm X-T5', 'Leica Q3'];
const lensOptions = ['35mm f/1.4', '50mm f/1.2', '24-70mm f/2.8', '85mm f/1.8', '16-35mm f/4'];
const apertures = ['f/1.4', 'f/1.8', 'f/2.8', 'f/4', 'f/5.6', 'f/8'];
const shutters = ['1/2000s', '1/1000s', '1/500s', '1/250s', '1/125s', '1/60s'];
const focals = ['24mm', '35mm', '50mm', '85mm', '105mm', '135mm'];

const dimensions: Array<[number, number]> = [
  [1200, 1600],
  [1600, 1200],
  [1400, 1400],
  [1200, 1800],
  [1600, 1067],
  [1080, 1350],
  [1600, 900],
  [1300, 1733],
];

const start = new Date('2026-11-20T09:00:00.000Z').getTime();
const day = 24 * 60 * 60 * 1000;

export const photos: Photo[] = seeds.map((seed, index) => {
  const [pexelsId, title, category, location, photographer] = seed;
  const [width, height] = dimensions[index % dimensions.length];
  const slugWords = title.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().split(' ');
  const tags = Array.from(new Set([category.toLowerCase(), ...slugWords, ...categoryTags[category]]));

  return {
    id: `p-${pexelsId}`,
    uri: pexels(pexelsId, 1600),
    thumb: pexels(pexelsId, 700),
    width,
    height,
    title,
    category,
    tags,
    location,
    photographer,
    date: new Date(start - (index * 7 + (index % 4) * 2) * day).toISOString(),
    likes: 180 + ((index * 137) % 2400),
    views: 1200 + ((index * 311) % 18000),
    camera: cameraBodies[index % cameraBodies.length],
    lens: lensOptions[index % lensOptions.length],
    iso: [100, 200, 400, 640, 800, 1600][index % 6],
    aperture: apertures[index % apertures.length],
    shutter: shutters[index % shutters.length],
    focalLength: focals[index % focals.length],
  };
});

const byCategory = (category: Category) => photos.filter((p) => p.category === category).map((p) => p.id);

const pick = (categories: Category[], limit: number) =>
  photos.filter((p) => categories.includes(p.category)).slice(0, limit).map((p) => p.id);

export const curatedAlbums: CuratedAlbum[] = [
  {
    id: 'golden-hour',
    title: 'Golden Hour',
    subtitle: 'Warm light, long shadows',
    description: 'A love letter to the last hour of daylight — fields, lakes and coastlines bathed in amber.',
    gradient: 'ember',
    emoji: '🌅',
    photoIds: pick(['Nature', 'Travel'], 12),
    tag: 'sunset',
  },
  {
    id: 'urban-jungle',
    title: 'Urban Jungle',
    subtitle: 'Cities after dark',
    description: 'Neon reflections, concrete canyons and the quiet drama of a city that never sleeps.',
    gradient: 'midnight',
    emoji: '🌃',
    photoIds: byCategory('City'),
    tag: 'city',
  },
  {
    id: 'wild-and-free',
    title: 'Wild & Free',
    subtitle: 'Creatures great and small',
    description: 'Portraits from the wild — from ocean giants to the smallest forest companions.',
    gradient: 'sunset',
    emoji: '🦊',
    photoIds: byCategory('Animals'),
    tag: 'wildlife',
  },
  {
    id: 'taste-of-the-world',
    title: 'Taste of the World',
    subtitle: 'A table for everyone',
    description: 'Markets, street food and slow mornings. A culinary tour told one frame at a time.',
    gradient: 'ember',
    emoji: '🍜',
    photoIds: byCategory('Food'),
    tag: 'food',
  },
  {
    id: 'faces-and-stories',
    title: 'Faces & Stories',
    subtitle: 'People, honestly',
    description: 'Candid moments and studio portraits that capture the texture of a life being lived.',
    gradient: 'candy',
    emoji: '👤',
    photoIds: byCategory('People'),
    tag: 'portrait',
  },
  {
    id: 'minimal-forms',
    title: 'Minimal Forms',
    subtitle: 'Less, but better',
    description: 'Shapes, gradients and negative space for when your eyes need a moment to breathe.',
    gradient: 'violet',
    emoji: '◻️',
    photoIds: byCategory('Abstract'),
    tag: 'minimal',
  },
  {
    id: 'on-the-road',
    title: 'On the Road',
    subtitle: 'Engines and open highways',
    description: 'Chrome, dust and the promise of a destination you have not met yet.',
    gradient: 'graphite',
    emoji: '🚗',
    photoIds: [...byCategory('Cars'), ...pick(['Travel'], 4)],
    tag: 'roadtrip',
  },
  {
    id: 'weekend-escape',
    title: 'Weekend Escape',
    subtitle: 'Two days, somewhere new',
    description: 'Short trips and big memories — the perfect inspo for your next long weekend.',
    gradient: 'ocean',
    emoji: '🧳',
    photoIds: pick(['Travel', 'Nature', 'Food'], 14),
    tag: 'weekend',
  },
];

export const stories: Story[] = [
  { id: 's1', title: 'Golden Hour', coverId: curatedAlbums[0].photoIds[0], albumId: 'golden-hour', gradient: 'ember' },
  { id: 's2', title: 'Night City', coverId: curatedAlbums[1].photoIds[0], albumId: 'urban-jungle', gradient: 'midnight' },
  { id: 's3', title: 'Wild Ones', coverId: curatedAlbums[2].photoIds[0], albumId: 'wild-and-free', gradient: 'sunset' },
  { id: 's4', title: 'Street Food', coverId: curatedAlbums[3].photoIds[0], albumId: 'taste-of-the-world', gradient: 'ember' },
  { id: 's5', title: 'Portraits', coverId: curatedAlbums[4].photoIds[0], albumId: 'faces-and-stories', gradient: 'candy' },
  { id: 's6', title: 'Minimal', coverId: curatedAlbums[5].photoIds[0], albumId: 'minimal-forms', gradient: 'violet' },
  { id: 's7', title: 'Road Trip', coverId: curatedAlbums[6].photoIds[0], albumId: 'on-the-road', gradient: 'graphite' },
  { id: 's8', title: 'Escapes', coverId: curatedAlbums[7].photoIds[0], albumId: 'weekend-escape', gradient: 'ocean' },
];

export const trendingSearches = ['golden hour', 'street food', 'wildlife', 'portraits', 'minimal', 'city lights', 'mountains', 'coffee'];

export const categories: Category[] = ['Nature', 'Travel', 'City', 'Food', 'Animals', 'People', 'Abstract', 'Cars', 'Fashion'];

export const photoOfTheDayId = photos[0].id;
