export type ThemeMode = 'system' | 'light' | 'dark';

export type Gradient = readonly [string, string];

export type Palette = {
  mode: 'light' | 'dark';
  bg: string;
  bgElevated: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  borderStrong: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  primary: string;
  primarySoft: string;
  accent: string;
  gold: string;
  danger: string;
  success: string;
  overlay: string;
  tabBar: string;
  isDark: boolean;
};

export const palettes: Record<'light' | 'dark', Palette> = {
  dark: {
    mode: 'dark',
    bg: '#08080C',
    bgElevated: '#0E0E15',
    surface: '#14141D',
    surfaceAlt: '#1D1D28',
    border: '#262633',
    borderStrong: '#343444',
    text: '#F6F6FA',
    textSecondary: '#B4B4C4',
    textMuted: '#7C7C90',
    primary: '#8B6BFF',
    primarySoft: 'rgba(139,107,255,0.16)',
    accent: '#FF5C8A',
    gold: '#FFC24B',
    danger: '#FF5D5D',
    success: '#3DDC97',
    overlay: 'rgba(4,4,8,0.72)',
    tabBar: 'rgba(12,12,19,0.98)',
    isDark: true,
  },
  light: {
    mode: 'light',
    bg: '#F6F6FA',
    bgElevated: '#FFFFFF',
    surface: '#FFFFFF',
    surfaceAlt: '#EDEDF4',
    border: '#E3E3EC',
    borderStrong: '#D2D2DE',
    text: '#0B0B12',
    textSecondary: '#52525F',
    textMuted: '#8A8A99',
    primary: '#6C4CFF',
    primarySoft: 'rgba(108,76,255,0.12)',
    accent: '#F43F72',
    gold: '#D99A12',
    danger: '#E23B3B',
    success: '#12A56D',
    overlay: 'rgba(8,8,14,0.55)',
    tabBar: 'rgba(255,255,255,0.98)',
    isDark: false,
  },
};

export const gradients = {
  violet: ['#7C5CFF', '#C05CFF'],
  sunset: ['#FF7A59', '#FF3D77'],
  ocean: ['#2E7BFF', '#21D4C4'],
  forest: ['#1F8A5B', '#9BD14B'],
  ember: ['#FF9F1C', '#FF4D4D'],
  midnight: ['#1E2A78', '#5B2C83'],
  candy: ['#FF6FB5', '#8B6BFF'],
  graphite: ['#2B2B38', '#5C5C72'],
} as const satisfies Record<string, Gradient>;

export type GradientKey = keyof typeof gradients;

export const spacing = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  xxxl: 40,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 22,
  xxl: 30,
  pill: 999,
};

export const typography = {
  display: { fontSize: 34, fontWeight: '800' as const, letterSpacing: -0.8 },
  title: { fontSize: 26, fontWeight: '800' as const, letterSpacing: -0.5 },
  heading: { fontSize: 20, fontWeight: '700' as const, letterSpacing: -0.3 },
  subheading: { fontSize: 16, fontWeight: '700' as const },
  body: { fontSize: 15, fontWeight: '500' as const },
  small: { fontSize: 13, fontWeight: '500' as const },
  caption: { fontSize: 11, fontWeight: '600' as const, letterSpacing: 0.2 },
};

export const shadow = {
  card: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.18,
    shadowRadius: 18,
    elevation: 6,
  },
  soft: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
};

export const categoryGradients: Record<string, Gradient> = {
  Nature: gradients.forest,
  Travel: gradients.ocean,
  City: gradients.midnight,
  Food: gradients.ember,
  Animals: gradients.sunset,
  People: gradients.candy,
  Abstract: gradients.violet,
  Cars: gradients.graphite,
  Fashion: gradients.candy,
  Camera: gradients.graphite,
};
