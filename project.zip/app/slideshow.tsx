import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Image as ExpoImage } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ChevronLeft,
  ChevronRight,
  Heart,
  Pause,
  Play,
  Share2,
  X,
} from 'lucide-react-native';
import { useGallery } from '@/lib/store';
import { formatDate, sharePhoto } from '@/lib/utils';
import { successFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';
import type { Photo } from '@/types';

const SLIDE_MS = 4600;

export default function SlideshowScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const params = useLocalSearchParams<{ start?: string; album?: string; collection?: string }>();
  const { photos, resolveAlbum, curated, getPhoto, isFavorite, toggleFavorite, settings } = useGallery();

  const list = useMemo<Photo[]>(() => {
    if (params.album) {
      const resolved = resolveAlbum(params.album);
      if (resolved) return resolved.photos;
    }
    if (params.collection) {
      const collection = curated.find((c) => c.id === params.collection);
      if (collection) {
        return collection.photoIds
          .map((id) => getPhoto(id))
          .filter((p): p is Photo => Boolean(p));
      }
    }
    return photos;
  }, [params.album, params.collection, resolveAlbum, curated, getPhoto, photos]);

  const startIndex = useMemo(() => {
    const found = list.findIndex((p) => p.id === params.start);
    return found >= 0 ? found : 0;
  }, [list, params.start]);

  const [index, setIndex] = useState(startIndex);
  const [playing, setPlaying] = useState(settings.autoplay);
  const [chrome, setChrome] = useState(true);
  const opacity = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(1)).current;
  const progress = useRef(new Animated.Value(0)).current;

  const photo = list[index];

  useEffect(() => {
    setIndex((i) => Math.min(i, Math.max(list.length - 1, 0)));
  }, [list.length]);

  useEffect(() => {
    opacity.setValue(0);
    scale.setValue(1);
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 550, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1.12, duration: SLIDE_MS + 400, useNativeDriver: true }),
    ]).start();
  }, [index, opacity, scale]);

  useEffect(() => {
    if (!playing || list.length < 2) return;
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % list.length);
    }, SLIDE_MS);
    return () => clearInterval(timer);
  }, [playing, list.length]);

  useEffect(() => {
    progress.stopAnimation();
    if (!playing) {
      progress.setValue(0);
      return;
    }
    progress.setValue(0);
    const anim = Animated.timing(progress, {
      toValue: 1,
      duration: SLIDE_MS,
      useNativeDriver: false,
    });
    anim.start();
    return () => anim.stop();
  }, [index, playing, progress]);

  if (!photo) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={{ color: '#FFFFFF' }}>Nothing to play yet</Text>
        <Pressable onPress={() => router.back()} style={{ marginTop: 14 }}>
          <Text style={{ color: '#8B6BFF', fontWeight: '700' }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const favorite = isFavorite(photo.id);
  const goPrev = () => setIndex((i) => (i - 1 + list.length) % list.length);
  const goNext = () => setIndex((i) => (i + 1) % list.length);

  return (
    <View style={styles.root}>
      <StatusBar hidden />
      <Pressable style={StyleSheet.absoluteFill} onPress={() => setChrome((c) => !c)}>
        <Animated.View style={[StyleSheet.absoluteFill, { opacity, transform: [{ scale }] }]}>
          <ExpoImage
            source={{ uri: photo.uri }}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            blurRadius={40}
            transition={300}
          />
          <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.6)' }]} />
          <ExpoImage
            source={{ uri: photo.uri }}
            style={[StyleSheet.absoluteFill, { width, height }]}
            contentFit="contain"
            transition={300}
          />
        </Animated.View>
      </Pressable>

      {chrome ? (
        <>
          <LinearGradient
            colors={['rgba(0,0,0,0.8)', 'transparent']}
            style={[styles.topGradient, { paddingTop: insets.top + 10 }]}
            pointerEvents="box-none"
          >
            <View style={styles.topRow}>
              <Pressable onPress={() => router.back()} style={styles.iconButton} accessibilityLabel="Close slideshow">
                <X size={20} color="#FFFFFF" />
              </Pressable>
              <View style={styles.counterPill}>
                <Text style={styles.counterText}>
                  {index + 1} / {list.length}
                </Text>
              </View>
              <View style={styles.topActions}>
                <Pressable
                  onPress={() => {
                    toggleFavorite(photo.id);
                    successFeedback();
                  }}
                  style={styles.iconButton}
                  accessibilityLabel="Favorite"
                >
                  <Heart size={19} color={favorite ? '#FF5C8A' : '#FFFFFF'} fill={favorite ? '#FF5C8A' : 'transparent'} />
                </Pressable>
                <Pressable onPress={() => sharePhoto(photo)} style={styles.iconButton} accessibilityLabel="Share">
                  <Share2 size={18} color="#FFFFFF" />
                </Pressable>
              </View>
            </View>

            <View style={styles.progressTrack}>
              <Animated.View
                style={[
                  styles.progressFill,
                  {
                    width: progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
                  },
                ]}
              />
            </View>
          </LinearGradient>

          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.75)', 'rgba(0,0,0,0.95)']}
            style={[styles.bottomGradient, { paddingBottom: insets.bottom + 18 }]}
            pointerEvents="box-none"
          >
            <View style={styles.captionWrap}>
              <Text style={styles.captionTitle}>{photo.title}</Text>
              <Text style={styles.captionSub}>
                {photo.photographer} · {photo.location}
              </Text>
              <Text style={styles.captionDate}>{formatDate(photo.date)}</Text>
            </View>

            <View style={styles.controls}>
              <Pressable onPress={goPrev} style={styles.sideButton} accessibilityLabel="Previous photo">
                <ChevronLeft size={22} color="#FFFFFF" />
              </Pressable>
              <Pressable
                onPress={() => setPlaying((p) => !p)}
                style={styles.playButton}
                accessibilityLabel={playing ? 'Pause slideshow' : 'Play slideshow'}
              >
                {playing ? (
                  <Pause size={24} color="#0B0B12" fill="#0B0B12" />
                ) : (
                  <Play size={24} color="#0B0B12" fill="#0B0B12" />
                )}
              </Pressable>
              <Pressable onPress={goNext} style={styles.sideButton} accessibilityLabel="Next photo">
                <ChevronRight size={22} color="#FFFFFF" />
              </Pressable>
            </View>

            <Text style={styles.hint}>
              {playing ? 'Auto-playing your memories' : 'Paused · tap play to continue'} · tap anywhere to hide controls
            </Text>
          </LinearGradient>
        </>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000000' },
  center: { alignItems: 'center', justifyContent: 'center' },
  topGradient: { position: 'absolute', top: 0, left: 0, right: 0, paddingHorizontal: spacing.md, paddingBottom: 40 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  counterPill: { backgroundColor: 'rgba(255,255,255,0.16)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.pill },
  counterText: { color: '#FFFFFF', fontSize: 11.5, fontWeight: '700' },
  topActions: { flexDirection: 'row', gap: 8 },
  progressTrack: {
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.22)',
    marginTop: 14,
    overflow: 'hidden',
  },
  progressFill: { height: 3, backgroundColor: '#FFFFFF', borderRadius: 2 },
  bottomGradient: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: spacing.xl, paddingTop: 80 },
  captionWrap: { alignItems: 'center' },
  captionTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', letterSpacing: -0.4, textAlign: 'center' },
  captionSub: { color: 'rgba(255,255,255,0.78)', fontSize: 12.5, fontWeight: '500', marginTop: 4, textAlign: 'center' },
  captionDate: { color: 'rgba(255,255,255,0.55)', fontSize: 11, fontWeight: '500', marginTop: 2 },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 24, marginTop: 20 },
  sideButton: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  playButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  hint: { ...typography.caption, color: 'rgba(255,255,255,0.45)', textAlign: 'center', marginTop: 16, fontWeight: '500' },
});
