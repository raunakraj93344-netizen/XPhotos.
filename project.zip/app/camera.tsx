import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Image as ExpoImage } from 'expo-image';
import { CameraView, useCameraPermissions, type CameraType, type FlashMode } from 'expo-camera';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  CameraOff,
  Check,
  Grid2x2,
  Image as ImageIcon,
  RotateCcw,
  ShieldAlert,
  X,
  Zap,
  ZapOff,
} from 'lucide-react-native';
import { SmartImage } from '@/components/SmartImage';
import { useGallery } from '@/lib/store';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';

export default function CameraScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { addPhoto, photos } = useGallery();
  const [permission, requestPermission] = useCameraPermissions();

  const cameraRef = useRef<CameraView>(null);
  const requested = useRef(false);
  const flashOverlay = useRef(new Animated.Value(0)).current;

  const [facing, setFacing] = useState<CameraType>('back');
  const [flash, setFlash] = useState<FlashMode>('off');
  const [grid, setGrid] = useState(true);
  const [captured, setCaptured] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [available, setAvailable] = useState<boolean | null>(null);

  const lastShot = photos.find((p) => p.isCustom);

  useEffect(() => {
    CameraView.isAvailableAsync()
      .then((ok) => setAvailable(ok))
      .catch(() => setAvailable(false));
  }, []);

  useEffect(() => {
    if (permission && !permission.granted && permission.canAskAgain && !requested.current) {
      requested.current = true;
      requestPermission().catch(() => undefined);
    }
  }, [permission, requestPermission]);

  const capture = async () => {
    if (busy || !cameraRef.current) return;
    setBusy(true);
    setError(null);
    try {
      const result = await cameraRef.current.takePictureAsync({ quality: 0.85 });
      if (result?.uri) {
        Animated.sequence([
          Animated.timing(flashOverlay, { toValue: 0.85, duration: 60, useNativeDriver: true }),
          Animated.timing(flashOverlay, { toValue: 0, duration: 220, useNativeDriver: true }),
        ]).start();
        setCaptured(result.uri);
      } else {
        setError('The camera did not return a photo. Try again.');
      }
    } catch {
      setError('Could not capture a photo. Check camera access and try again.');
    } finally {
      setBusy(false);
    }
  };

  const usePhoto = () => {
    if (!captured) return;
    const photo = addPhoto(captured);
    successFeedback();
    router.replace(`/photo/${photo.id}`);
  };

  if (available === false) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <View style={styles.permissionIcon}>
          <CameraOff size={30} color="#FFFFFF" />
        </View>
        <Text style={styles.permissionTitle}>Camera unavailable</Text>
        <Text style={styles.permissionText}>
          We could not find a camera on this device or browser. You can still browse and curate your library.
        </Text>
        <Pressable onPress={() => router.back()} style={styles.permissionButton}>
          <Text style={styles.permissionButtonText}>Back to library</Text>
        </Pressable>
      </View>
    );
  }

  if (!permission) {
    return (
      <View style={[styles.root, styles.center]}>
        <StatusBar style="light" />
        <Text style={styles.permissionText}>Preparing camera…</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <Pressable onPress={() => router.back()} style={[styles.close, { top: insets.top + 10 }]}>
          <X size={20} color="#FFFFFF" />
        </Pressable>
        <View style={styles.permissionIcon}>
          <ShieldAlert size={30} color="#FFFFFF" />
        </View>
        <Text style={styles.permissionTitle}>Camera access needed</Text>
        <Text style={styles.permissionText}>
          XPhotos uses your camera to capture new memories. Photos stay on your device.
        </Text>
        <Pressable
          onPress={() => requestPermission()}
          style={styles.permissionButton}
        >
          <Text style={styles.permissionButtonText}>Allow camera access</Text>
        </Pressable>
        <Pressable onPress={() => router.back()} style={styles.permissionGhost}>
          <Text style={styles.permissionGhostText}>Not now</Text>
        </Pressable>
      </View>
    );
  }

  if (captured) {
    return (
      <View style={styles.root}>
        <StatusBar hidden />
        <ExpoImage source={{ uri: captured }} style={StyleSheet.absoluteFill} contentFit="cover" />
        <LinearGradient
          colors={['rgba(0,0,0,0.7)', 'transparent']}
          style={[styles.previewTop, { paddingTop: insets.top + 10 }]}
        />
        <Pressable
          onPress={() => {
            setCaptured(null);
            router.back();
          }}
          style={[styles.cameraIcon, { position: 'absolute', left: spacing.md, top: insets.top + 10 }]}
          accessibilityLabel="Discard photo"
        >
          <X size={20} color="#FFFFFF" />
        </Pressable>
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.85)']}
          style={[styles.previewBottom, { paddingBottom: insets.bottom + 24 }]}
        >
          <Text style={styles.previewTitle}>Looking good</Text>
          <Text style={styles.previewSub}>Add this shot to your XPhotos library?</Text>
          <View style={styles.previewActions}>
            <Pressable
              onPress={() => setCaptured(null)}
              style={[styles.previewButton, { backgroundColor: 'rgba(255,255,255,0.14)' }]}
            >
              <RotateCcw size={17} color="#FFFFFF" />
              <Text style={[styles.previewButtonText, { color: '#FFFFFF' }]}>Retake</Text>
            </Pressable>
            <Pressable
              onPress={usePhoto}
              style={[styles.previewButton, { backgroundColor: '#FFFFFF' }]}
            >
              <Check size={17} color="#0B0B12" />
              <Text style={[styles.previewButtonText, { color: '#0B0B12' }]}>Use photo</Text>
            </Pressable>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <StatusBar hidden />
      <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing={facing} flash={flash} animateShutter={false} />

      <LinearGradient
        colors={['rgba(0,0,0,0.72)', 'transparent']}
        style={[styles.cameraTop, { paddingTop: insets.top + 8 }]}
      >
        <View style={styles.cameraTopRow}>
          <Pressable onPress={() => router.back()} style={styles.cameraIcon} accessibilityLabel="Close camera">
            <ArrowLeft size={20} color="#FFFFFF" />
          </Pressable>
          <View style={styles.modePill}>
            <View style={styles.modeDot} />
            <Text style={styles.modeText}>PHOTO</Text>
          </View>
          <View style={styles.topTools}>
            <Pressable
              onPress={() => setFlash((f) => (f === 'off' ? 'on' : f === 'on' ? 'auto' : 'off'))}
              style={styles.cameraIcon}
              accessibilityLabel="Toggle flash"
            >
              {flash === 'off' ? <ZapOff size={18} color="#FFFFFF" /> : <Zap size={18} color={flash === 'auto' ? '#FFD479' : '#FFFFFF'} />}
            </Pressable>
            <Pressable
              onPress={() => setGrid((g) => !g)}
              style={[styles.cameraIcon, grid && { backgroundColor: 'rgba(255,255,255,0.28)' }]}
              accessibilityLabel="Toggle grid"
            >
              <Grid2x2 size={18} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>
        {error ? (
          <View style={styles.errorBanner}>
            <Text style={styles.errorText}>{error}</Text>
            <Pressable onPress={() => setError(null)} hitSlop={8}>
              <X size={14} color="#FFFFFF" />
            </Pressable>
          </View>
        ) : null}
      </LinearGradient>

      {grid ? (
        <View style={StyleSheet.absoluteFill} pointerEvents="none">
          <View style={[styles.gridLineV, { left: `${100 / 3}%` }]} />
          <View style={[styles.gridLineV, { left: `${(100 / 3) * 2}%` }]} />
          <View style={[styles.gridLineH, { top: `${100 / 3}%` }]} />
          <View style={[styles.gridLineH, { top: `${(100 / 3) * 2}%` }]} />
          <View style={styles.focusFrame}>
            <View style={[styles.corner, { top: 0, left: 0, borderTopWidth: 2, borderLeftWidth: 2 }]} />
            <View style={[styles.corner, { top: 0, right: 0, borderTopWidth: 2, borderRightWidth: 2 }]} />
            <View style={[styles.corner, { bottom: 0, left: 0, borderBottomWidth: 2, borderLeftWidth: 2 }]} />
            <View style={[styles.corner, { bottom: 0, right: 0, borderBottomWidth: 2, borderRightWidth: 2 }]} />
          </View>
        </View>
      ) : null}

      <Animated.View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, { backgroundColor: '#FFFFFF', opacity: flashOverlay }]}
      />

      <LinearGradient
        colors={['transparent', 'rgba(0,0,0,0.82)']}
        style={[styles.cameraBottom, { paddingBottom: insets.bottom + 20 }]}
      >
        <Text style={styles.hint}>
          {flash === 'on' ? 'Flash on' : flash === 'auto' ? 'Flash auto' : 'Tap the shutter to capture'}
        </Text>
        <View style={styles.shutterRow}>
          <Pressable
            onPress={() => {
              if (lastShot) router.replace(`/photo/${lastShot.id}`);
              else router.back();
            }}
            style={styles.galleryThumb}
            accessibilityLabel="Open last capture"
          >
            {lastShot ? (
              <SmartImage uri={lastShot.thumb} style={styles.thumbImage} radius={12} />
            ) : (
              <View style={[styles.thumbImage, styles.thumbEmpty]}>
                <ImageIcon size={18} color="rgba(255,255,255,0.7)" />
              </View>
            )}
          </Pressable>

          <Pressable onPress={capture} disabled={busy} style={styles.shutterOuter} accessibilityLabel="Capture photo">
            <View style={[styles.shutterInner, busy && { opacity: 0.6 }]} />
          </Pressable>

          <Pressable
            onPress={() => {
              tapFeedback();
              setFacing((f) => (f === 'back' ? 'front' : 'back'));
            }}
            style={styles.galleryThumb}
            accessibilityLabel="Flip camera"
          >
            <RotateCcw size={22} color="#FFFFFF" />
          </Pressable>
        </View>
        <Text style={styles.cameraFooter}>XPhotos Camera · {width > 500 ? 'Wide' : '1×'} · Auto HDR</Text>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000000' },
  center: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.xl },
  permissionIcon: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  permissionTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', textAlign: 'center' },
  permissionText: { color: 'rgba(255,255,255,0.65)', fontSize: 13, fontWeight: '500', textAlign: 'center', lineHeight: 20, marginTop: 8, maxWidth: 320 },
  permissionButton: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 26,
    paddingVertical: 14,
    borderRadius: radius.pill,
    marginTop: spacing.xl,
  },
  permissionButtonText: { color: '#0B0B12', fontSize: 13.5, fontWeight: '800' },
  permissionGhost: { marginTop: spacing.md, padding: 8 },
  permissionGhostText: { color: 'rgba(255,255,255,0.6)', fontSize: 12.5, fontWeight: '600' },
  close: { position: 'absolute', left: spacing.lg, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center' },
  cameraTop: { position: 'absolute', top: 0, left: 0, right: 0, paddingHorizontal: spacing.md, paddingBottom: 40 },
  cameraTopRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cameraIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topTools: { flexDirection: 'row', gap: 8 },
  modePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: radius.pill,
  },
  modeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#FF5C8A' },
  modeText: { color: '#FFFFFF', fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(255,93,93,0.9)',
    marginTop: 12,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: radius.md,
  },
  errorText: { color: '#FFFFFF', fontSize: 11.5, fontWeight: '600', flex: 1 },
  gridLineV: { position: 'absolute', top: 0, bottom: 0, width: StyleSheet.hairlineWidth, backgroundColor: 'rgba(255,255,255,0.28)' },
  gridLineH: { position: 'absolute', left: 0, right: 0, height: StyleSheet.hairlineWidth, backgroundColor: 'rgba(255,255,255,0.28)' },
  focusFrame: { position: 'absolute', alignSelf: 'center', top: '38%', width: 120, height: 120 },
  corner: { position: 'absolute', width: 22, height: 22, borderColor: 'rgba(255,255,255,0.65)' },
  cameraBottom: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingTop: 50, paddingHorizontal: spacing.xl },
  hint: { ...typography.caption, color: 'rgba(255,255,255,0.65)', textAlign: 'center', marginBottom: 16, fontWeight: '600' },
  shutterRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.lg },
  galleryThumb: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.14)',
    overflow: 'hidden',
  },
  thumbImage: { width: 52, height: 52 },
  thumbEmpty: { alignItems: 'center', justifyContent: 'center' },
  shutterOuter: {
    width: 78,
    height: 78,
    borderRadius: 39,
    borderWidth: 4,
    borderColor: 'rgba(255,255,255,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  shutterInner: { width: 62, height: 62, borderRadius: 31, backgroundColor: '#FFFFFF' },
  cameraFooter: { ...typography.caption, color: 'rgba(255,255,255,0.4)', textAlign: 'center', marginTop: 16, fontWeight: '600' },
  previewTop: { position: 'absolute', top: 0, left: 0, right: 0, height: 160 },
  previewBottom: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: spacing.xl, paddingTop: 70 },
  previewTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: '800', letterSpacing: -0.4, textAlign: 'center' },
  previewSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12.5, fontWeight: '500', textAlign: 'center', marginTop: 4 },
  previewActions: { flexDirection: 'row', gap: 10, marginTop: spacing.xl },
  previewButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingVertical: 14,
    borderRadius: radius.pill,
  },
  previewButtonText: { fontSize: 13.5, fontWeight: '800' },
});
