import { useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Image as ExpoImage } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  CalendarDays,
  Download,
  FolderPlus,
  Heart,
  Info,
  MapPin,
  Play,
  Share2,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react-native';
import { Sheet } from '@/components/Sheet';
import { SmartImage } from '@/components/SmartImage';
import { Avatar } from '@/components/Avatar';
import { IconButton } from '@/components/IconButton';
import { useGallery } from '@/lib/store';
import { downloadPhoto, formatCount, formatDate, sharePhoto } from '@/lib/utils';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';
import type { Photo } from '@/types';

export default function PhotoViewer() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const params = useLocalSearchParams<{ id?: string }>();
  const {
    photos,
    isFavorite,
    toggleFavorite,
    userAlbums,
    addPhotosToAlbum,
    deletePhotos,
  } = useGallery();

  const initialIndex = useMemo(() => {
    const found = photos.findIndex((p) => p.id === params.id);
    return found >= 0 ? found : 0;
  }, [photos, params.id]);

  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [infoOpen, setInfoOpen] = useState(false);
  const [albumOpen, setAlbumOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [zoom, setZoom] = useState(false);
  const [following, setFollowing] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const listRef = useRef<FlatList<Photo>>(null);
  const lastTap = useRef(0);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const photo = photos[currentIndex] ?? photos[0];

  useEffect(() => {
    const next = photos.findIndex((p) => p.id === params.id);
    if (next >= 0 && next !== currentIndex) {
      setCurrentIndex(next);
      listRef.current?.scrollToIndex({ index: next, animated: false });
    }
  }, [params.id]);

  useEffect(() => {
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  const showToast = (message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 1900);
  };

  const related = useMemo(() => {
    if (!photo) return [];
    return photos.filter((p) => p.category === photo.category && p.id !== photo.id).slice(0, 10);
  }, [photos, photo]);

  const handleScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const next = Math.round(event.nativeEvent.contentOffset.x / width);
    if (next !== currentIndex) {
      setCurrentIndex(next);
      setZoom(false);
    }
  };

  const handleTap = () => {
    const now = Date.now();
    if (now - lastTap.current < 280) {
      setZoom((z) => !z);
      lastTap.current = 0;
    } else {
      lastTap.current = now;
    }
  };

  if (!photo) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text style={{ color: '#FFFFFF' }}>Photo not found</Text>
        <Pressable onPress={() => router.back()} style={{ marginTop: 16 }}>
          <Text style={{ color: '#8B6BFF', fontWeight: '700' }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const favorite = isFavorite(photo.id);

  return (
    <View style={styles.root}>
      <StatusBar style="light" />

      <FlatList
        ref={listRef}
        data={photos}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        initialScrollIndex={initialIndex}
        getItemLayout={(_, index) => ({ length: width, offset: width * index, index })}
        onMomentumScrollEnd={handleScrollEnd}
        onScrollToIndexFailed={({ index }) => {
          setTimeout(() => listRef.current?.scrollToIndex({ index, animated: false }), 60);
        }}
        windowSize={3}
        initialNumToRender={1}
        maxToRenderPerBatch={2}
        renderItem={({ item }) => (
          <Pressable onPress={handleTap} style={{ width, height }}>
            <ExpoImage
              source={{ uri: item.uri }}
              style={StyleSheet.absoluteFill}
              contentFit="cover"
              blurRadius={40}
              transition={200}
            />
            <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.55)' }]} />
            <SmartImage
              uri={item.uri}
              contentFit="contain"
              transparent
              style={[
                StyleSheet.absoluteFill,
                zoom ? { transform: [{ scale: 2 }] } : undefined,
              ]}
            />
          </Pressable>
        )}
      />

      <LinearGradient
        colors={['rgba(0,0,0,0.72)', 'transparent']}
        style={[styles.topGradient, { paddingTop: insets.top + 8 }]}
        pointerEvents="box-none"
      >
        <View style={styles.topRow}>
          <IconButton
            icon={<ArrowLeft size={20} color="#FFFFFF" />}
            variant="ghost"
            onPress={() => router.back()}
            accessibilityLabel="Close viewer"
          />
          <View style={styles.counterPill}>
            <Text style={styles.counterText}>
              {currentIndex + 1} / {photos.length}
            </Text>
          </View>
          <View style={styles.topActions}>
            <IconButton
              icon={<Info size={18} color="#FFFFFF" />}
              variant="ghost"
              onPress={() => setInfoOpen(true)}
              accessibilityLabel="Photo info"
            />
            <IconButton
              icon={<Share2 size={18} color="#FFFFFF" />}
              variant="ghost"
              onPress={() => sharePhoto(photo)}
              accessibilityLabel="Share photo"
            />
            <IconButton
              icon={<Download size={18} color="#FFFFFF" />}
              variant="ghost"
              onPress={() => {
                downloadPhoto(photo);
                showToast('Download started');
              }}
              accessibilityLabel="Download photo"
            />
          </View>
        </View>
      </LinearGradient>

      <LinearGradient
        colors={['transparent', 'rgba(0,0,0,0.82)', 'rgba(0,0,0,0.96)']}
        style={[styles.bottomGradient, { paddingBottom: insets.bottom + 16 }]}
        pointerEvents="box-none"
      >
        <View style={styles.bottomRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.photoTitle}>{photo.title}</Text>
            <View style={styles.metaRow}>
              <MapPin size={12} color="rgba(255,255,255,0.7)" />
              <Text style={styles.metaText}>{photo.location}</Text>
              <View style={styles.metaDot} />
              <CalendarDays size={12} color="rgba(255,255,255,0.7)" />
              <Text style={styles.metaText}>{formatDate(photo.date)}</Text>
            </View>
            <View style={styles.photographerRow}>
              <Avatar name={photo.photographer} size={30} gradientKey="candy" />
              <View style={{ flex: 1 }}>
                <Text style={styles.photographerName}>{photo.photographer}</Text>
                <Text style={styles.photographerRole}>
                  {formatCount(photo.views)} views · {formatCount(photo.likes)} likes
                </Text>
              </View>
              <Pressable
                onPress={() => {
                  setFollowing((f) => !f);
                  tapFeedback();
                }}
                style={[
                  styles.followButton,
                  following && { backgroundColor: 'rgba(255,255,255,0.18)' },
                ]}
              >
                <Text style={styles.followText}>{following ? 'Following' : 'Follow'}</Text>
              </Pressable>
            </View>
          </View>

          <View style={styles.sideActions}>
            <Pressable
              onPress={() => {
                toggleFavorite(photo.id);
                successFeedback();
              }}
              style={[styles.actionCircle, favorite && { backgroundColor: 'rgba(255,92,138,0.9)' }]}
            >
              <Heart size={20} color="#FFFFFF" fill={favorite ? '#FFFFFF' : 'transparent'} />
            </Pressable>
            <Pressable
              onPress={() => router.push(`/slideshow?start=${photo.id}`)}
              style={styles.actionCircle}
            >
              <Play size={19} color="#FFFFFF" fill="#FFFFFF" />
            </Pressable>
          </View>
        </View>

        <View style={styles.quickRow}>
          <Pressable
            onPress={() => setAlbumOpen(true)}
            style={styles.quickButton}
          >
            <FolderPlus size={15} color="#FFFFFF" />
            <Text style={styles.quickText}>Add to album</Text>
          </Pressable>
          <Pressable onPress={() => setInfoOpen(true)} style={styles.quickButton}>
            <SlidersHorizontal size={15} color="#FFFFFF" />
            <Text style={styles.quickText}>Details</Text>
          </Pressable>
          <Pressable
            onPress={() => setDeleteOpen(true)}
            style={[styles.quickButton, { borderColor: 'rgba(255,93,93,0.5)' }]}
          >
            <Trash2 size={15} color="#FF8080" />
            <Text style={[styles.quickText, { color: '#FF8080' }]}>Delete</Text>
          </Pressable>
        </View>
      </LinearGradient>

      {toast ? (
        <View style={[styles.toast, { top: insets.top + 64 }]}>
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      ) : null}

      <Sheet visible={infoOpen} onClose={() => setInfoOpen(false)} title="Photo details" scroll tone="dark">
        <View style={styles.infoHeader}>
          <SmartImage uri={photo.thumb} style={styles.infoThumb} radius={radius.md} />
          <View style={{ flex: 1 }}>
            <Text style={styles.infoTitle}>{photo.title}</Text>
            <Text style={styles.infoSub}>
              {photo.category} · {photo.location}
            </Text>
            <Text style={styles.infoSub}>{formatDate(photo.date)}</Text>
          </View>
        </View>

        <View style={styles.exifGrid}>
          {[
            { label: 'Camera', value: photo.camera },
            { label: 'Lens', value: photo.lens },
            { label: 'ISO', value: `${photo.iso}` },
            { label: 'Aperture', value: photo.aperture },
            { label: 'Shutter', value: photo.shutter },
            { label: 'Focal length', value: photo.focalLength },
            { label: 'Resolution', value: `${photo.width} × ${photo.height}` },
            { label: 'Engagement', value: `${formatCount(photo.likes)} likes` },
          ].map((row) => (
            <View key={row.label} style={styles.exifCell}>
              <Text style={styles.exifLabel}>{row.label}</Text>
              <Text style={styles.exifValue}>{row.value}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.tagsLabel}>TAGS</Text>
        <View style={styles.tagWrap}>
          {photo.tags.slice(0, 10).map((tag) => (
            <View key={tag} style={styles.tag}>
              <Text style={styles.tagText}>#{tag}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.tagsLabel}>MORE LIKE THIS</Text>
        <FlatList
          data={related}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ gap: 8 }}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => {
                setInfoOpen(false);
                router.push(`/photo/${item.id}`);
              }}
            >
              <SmartImage uri={item.thumb} style={styles.relatedImage} radius={radius.md} />
            </Pressable>
          )}
        />

        <View style={styles.infoActions}>
          <Pressable
            onPress={() => {
              toggleFavorite(photo.id);
              successFeedback();
            }}
            style={[styles.infoAction, { backgroundColor: '#1D1D28' }]}
          >
            <Heart size={16} color={favorite ? '#FF5C8A' : '#F6F6FA'} fill={favorite ? '#FF5C8A' : 'transparent'} />
            <Text style={styles.infoActionText}>{favorite ? 'Favorited' : 'Favorite'}</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              downloadPhoto(photo);
              showToast('Download started');
            }}
            style={[styles.infoAction, { backgroundColor: '#1D1D28' }]}
          >
            <Download size={16} color="#F6F6FA" />
            <Text style={styles.infoActionText}>Download</Text>
          </Pressable>
        </View>
      </Sheet>

      <Sheet visible={albumOpen} onClose={() => setAlbumOpen(false)} title="Add to album" tone="dark" scroll>
        {userAlbums.length === 0 ? (
          <View style={{ paddingBottom: 12 }}>
            <Text style={[styles.emptyText, { color: '#8E8E9A' }]}>
              No albums yet. Create one from the Albums tab, then come back to add this shot.
            </Text>
            <Pressable
              onPress={() => {
                setAlbumOpen(false);
                router.push('/albums');
              }}
              style={styles.emptyButton}
            >
              <Text style={styles.emptyButtonText}>Go to albums</Text>
            </Pressable>
          </View>
        ) : (
          userAlbums.map((album) => (
            <Pressable
              key={album.id}
              onPress={() => {
                addPhotosToAlbum(album.id, [photo.id]);
                successFeedback();
                setAlbumOpen(false);
                showToast(`Added to ${album.title}`);
              }}
              style={styles.albumRow}
            >
              <Text style={{ fontSize: 22 }}>{album.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.albumRowTitle}>{album.title}</Text>
                <Text style={styles.albumRowSub}>{album.photoIds.length} photos</Text>
              </View>
              <FolderPlus size={17} color="#8E8E9A" />
            </Pressable>
          ))
        )}
      </Sheet>

      <Sheet visible={deleteOpen} onClose={() => setDeleteOpen(false)} title="Delete this photo?" tone="dark">
        <Text style={[styles.emptyText, { color: '#8E8E9A', marginBottom: 16 }]}>
          “{photo.title}” will be removed from your XPhotos library. This cannot be undone.
        </Text>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Pressable
            onPress={() => setDeleteOpen(false)}
            style={[styles.emptyButton, { flex: 1, backgroundColor: '#1D1D28' }]}
          >
            <Text style={[styles.emptyButtonText, { color: '#F6F6FA' }]}>Cancel</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              deletePhotos([photo.id]);
              setDeleteOpen(false);
              router.back();
            }}
            style={[styles.emptyButton, { flex: 1, backgroundColor: '#FF5D5D' }]}
          >
            <Text style={[styles.emptyButtonText, { color: '#FFFFFF' }]}>Delete</Text>
          </Pressable>
        </View>
      </Sheet>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000000' },
  center: { alignItems: 'center', justifyContent: 'center' },
  topGradient: { position: 'absolute', top: 0, left: 0, right: 0, paddingBottom: 40 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 8 },
  counterPill: {
    backgroundColor: 'rgba(255,255,255,0.16)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  counterText: { color: '#FFFFFF', fontSize: 11.5, fontWeight: '700' },
  topActions: { flexDirection: 'row', gap: 2 },
  bottomGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: spacing.lg,
    paddingTop: 60,
  },
  bottomRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 12 },
  photoTitle: { color: '#FFFFFF', fontSize: 23, fontWeight: '800', letterSpacing: -0.4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5, flexWrap: 'wrap' },
  metaText: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: '500' },
  metaDot: { width: 3, height: 3, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.4)', marginHorizontal: 2 },
  photographerRow: { flexDirection: 'row', alignItems: 'center', gap: 9, marginTop: 14 },
  photographerName: { color: '#FFFFFF', fontSize: 12.5, fontWeight: '700' },
  photographerRole: { color: 'rgba(255,255,255,0.6)', fontSize: 10, fontWeight: '500', marginTop: 1 },
  followButton: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    paddingHorizontal: 13,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  followText: { color: '#0B0B12', fontSize: 11, fontWeight: '800' },
  sideActions: { gap: 10, paddingBottom: 4 },
  actionCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: 'rgba(255,255,255,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.22)',
  },
  quickRow: { flexDirection: 'row', gap: 8, marginTop: 16 },
  quickButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: radius.pill,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  quickText: { color: '#FFFFFF', fontSize: 11.5, fontWeight: '600' },
  toast: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: 'rgba(20,20,29,0.96)',
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255,255,255,0.14)',
  },
  toastText: { color: '#FFFFFF', fontSize: 12, fontWeight: '600' },
  infoHeader: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  infoThumb: { width: 76, height: 76 },
  infoTitle: { color: '#F6F6FA', fontSize: 16, fontWeight: '800' },
  infoSub: { color: '#8E8E9A', fontSize: 11.5, fontWeight: '500', marginTop: 2 },
  exifGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  exifCell: {
    width: '47.5%',
    backgroundColor: '#1D1D28',
    borderRadius: radius.md,
    padding: 10,
  },
  exifLabel: { color: '#8E8E9A', fontSize: 9, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
  exifValue: { color: '#F6F6FA', fontSize: 12.5, fontWeight: '600', marginTop: 3 },
  tagsLabel: { color: '#8E8E9A', fontSize: 9.5, fontWeight: '800', letterSpacing: 0.9, marginTop: 18, marginBottom: 9 },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  tag: { backgroundColor: '#1D1D28', borderRadius: radius.pill, paddingHorizontal: 11, paddingVertical: 6 },
  tagText: { color: '#B4B4C4', fontSize: 11.5, fontWeight: '600' },
  relatedImage: { width: 82, height: 82 },
  infoActions: { flexDirection: 'row', gap: 8, marginTop: 18 },
  infoAction: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingVertical: 12,
    borderRadius: radius.lg,
  },
  infoActionText: { color: '#F6F6FA', fontSize: 12, fontWeight: '700' },
  emptyText: { fontSize: 12.5, lineHeight: 19, fontWeight: '500' },
  emptyButton: { paddingVertical: 13, borderRadius: radius.lg, alignItems: 'center', backgroundColor: '#F6F6FA' },
  emptyButtonText: { color: '#0B0B12', fontSize: 13, fontWeight: '800' },
  albumRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13 },
  albumRowTitle: { color: '#F6F6FA', fontSize: 14, fontWeight: '700' },
  albumRowSub: { color: '#8E8E9A', fontSize: 11, fontWeight: '500', marginTop: 1 },
});
