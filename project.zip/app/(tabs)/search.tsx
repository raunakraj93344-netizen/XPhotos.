import { useEffect, useMemo, useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ArrowUpRight,
  Clock,
  Search as SearchIcon,
  Sparkles,
  TrendingUp,
  X,
} from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { Chip } from '@/components/Chip';
import { SectionHeader } from '@/components/SectionHeader';
import { EmptyState } from '@/components/EmptyState';
import { PhotoGrid } from '@/components/PhotoGrid';
import { CategoryCard } from '@/components/cards';
import { useGallery, usePalette } from '@/lib/store';
import { categories, trendingSearches } from '@/data/photos';
import { searchPhotos } from '@/lib/utils';
import { tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography, type GradientKey } from '@/constants/theme';

const categoryTints: GradientKey[] = [
  'forest',
  'ocean',
  'midnight',
  'ember',
  'sunset',
  'candy',
  'violet',
  'graphite',
  'candy',
];

export default function SearchScreen() {
  const router = useRouter();
  const palette = usePalette();
  const { width } = useWindowDimensions();
  const { photos, recentSearches, recordSearch, clearRecentSearches, favorites } = useGallery();
  const params = useLocalSearchParams<{ q?: string }>();

  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  useEffect(() => {
    if (typeof params.q === 'string' && params.q.length > 0) {
      setQuery(params.q);
      setCategoryFilter('all');
      recordSearch(params.q);
      router.setParams({ q: '' });
    }
  }, [params.q]);

  const results = useMemo(() => {
    const base = searchPhotos(photos, query);
    if (categoryFilter === 'all') return base;
    return base.filter((p) => p.category === categoryFilter);
  }, [photos, query, categoryFilter]);

  const availableCategories = useMemo(() => {
    const base = searchPhotos(photos, query);
    return categories.filter((category) => base.some((p) => p.category === category));
  }, [photos, query]);

  const active = query.trim().length > 0;
  const cardWidth = (width - spacing.lg * 2 - 10) / 2;

  const applyQuery = (next: string) => {
    setQuery(next);
    setCategoryFilter('all');
    recordSearch(next);
  };

  return (
    <Screen>
      <View style={{ paddingHorizontal: spacing.lg }}>
        <Text style={[styles.eyebrow, { color: palette.textMuted }]}>FIND ANYTHING</Text>
        <Text style={[styles.title, { color: palette.text }]}>Search</Text>

        <View style={[styles.inputWrap, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <SearchIcon size={18} color={palette.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => recordSearch(query)}
            placeholder="Places, people, colors, moods…"
            placeholderTextColor={palette.textMuted}
            style={[styles.input, { color: palette.text }]}
            returnKeyType="search"
            autoCorrect={false}
            accessibilityLabel="Search photos"
          />
          {query.length > 0 ? (
            <Pressable
              onPress={() => {
                setQuery('');
                setCategoryFilter('all');
              }}
              style={[styles.clear, { backgroundColor: palette.surfaceAlt }]}
              accessibilityLabel="Clear search"
            >
              <X size={13} color={palette.textSecondary} />
            </Pressable>
          ) : null}
        </View>
      </View>

      {active ? (
        <PhotoGrid
          photos={results}
          favorites={favorites}
          showLabels
          onPressPhoto={(photo) => router.push(`/photo/${photo.id}`)}
          header={
            <View style={{ paddingTop: spacing.lg }}>
              <View style={styles.resultsRow}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.resultsTitle, { color: palette.text }]}>
                    {results.length} {results.length === 1 ? 'result' : 'results'}
                  </Text>
                  <Text style={[styles.resultsSub, { color: palette.textMuted }]} numberOfLines={1}>
                    for “{query.trim()}”
                  </Text>
                </View>
                <View style={[styles.aiBadge, { backgroundColor: palette.primarySoft }]}>
                  <Sparkles size={12} color={palette.primary} />
                  <Text style={[styles.aiBadgeText, { color: palette.primary }]}>Smart match</Text>
                </View>
              </View>

              {availableCategories.length > 1 ? (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ gap: 8, paddingBottom: spacing.lg, paddingTop: 4 }}
                >
                  <Chip
                    label="All"
                    size="sm"
                    active={categoryFilter === 'all'}
                    onPress={() => setCategoryFilter('all')}
                  />
                  {availableCategories.map((category) => (
                    <Chip
                      key={category}
                      label={category}
                      size="sm"
                      active={categoryFilter === category}
                      onPress={() => setCategoryFilter(category)}
                    />
                  ))}
                </ScrollView>
              ) : (
                <View style={{ height: spacing.md }} />
              )}
            </View>
          }
          empty={
            <EmptyState
              icon={SearchIcon}
              title="No photos found"
              message={`We could not find anything for “${query.trim()}”. Try a place, a category, or a mood.`}
              actionLabel="Clear search"
              onAction={() => setQuery('')}
            />
          }
          footer={
            <View style={{ paddingTop: spacing.xl }}>
              <Text style={[styles.tryTitle, { color: palette.text }]}>Try searching for</Text>
              <View style={styles.tagWrap}>
                {trendingSearches.slice(0, 5).map((tag) => (
                  <Chip key={tag} label={tag} size="sm" onPress={() => applyQuery(tag)} />
                ))}
              </View>
            </View>
          }
        />
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 120, paddingHorizontal: spacing.lg }}
          keyboardShouldPersistTaps="handled"
        >
          {recentSearches.length > 0 ? (
            <View style={{ marginTop: spacing.xl }}>
              <SectionHeader
                title="Recent"
                actionLabel="Clear"
                onAction={clearRecentSearches}
              />
              {recentSearches.map((item) => (
                <Pressable
                  key={item}
                  onPress={() => {
                    tapFeedback();
                    applyQuery(item);
                  }}
                  style={[styles.recentRow, { borderBottomColor: palette.border }]}
                >
                  <View style={[styles.recentIcon, { backgroundColor: palette.surfaceAlt }]}>
                    <Clock size={14} color={palette.textMuted} />
                  </View>
                  <Text style={[styles.recentText, { color: palette.text }]}>{item}</Text>
                  <ArrowUpRight size={15} color={palette.textMuted} />
                </Pressable>
              ))}
            </View>
          ) : null}

          <View style={{ marginTop: spacing.xl }}>
            <SectionHeader title="Trending now" subtitle="Popular searches this week" />
            <View style={styles.tagWrap}>
              {trendingSearches.map((tag, index) => (
                <Chip
                  key={tag}
                  label={`${index < 3 ? '🔥 ' : ''}${tag}`}
                  onPress={() => applyQuery(tag)}
                />
              ))}
            </View>
          </View>

          <View style={{ marginTop: spacing.xxl }}>
            <SectionHeader title="Browse categories" subtitle="Nine worlds, thousands of frames" />
            <View style={styles.categoryGrid}>
              {categories.map((category, index) => {
                const cover = photos.find((p) => p.category === category);
                const count = photos.filter((p) => p.category === category).length;
                return (
                  <CategoryCard
                    key={category}
                    title={category}
                    count={count}
                    uri={cover?.thumb}
                    gradient={categoryTints[index % categoryTints.length]}
                    width={cardWidth}
                    height={96}
                    onPress={() => applyQuery(category)}
                  />
                );
              })}
            </View>
          </View>

          <LinearGradient
            colors={['#221A44', '#3A2060', '#54265E']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.tipCard}
          >
            <View style={styles.tipIcon}>
              <TrendingUp size={18} color="#FFD479" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.tipTitle}>Search like a pro</Text>
              <Text style={styles.tipText}>
                Combine a place and a mood — try “tokyo night” or “golden portrait”. Results update as you type.
              </Text>
            </View>
          </LinearGradient>
        </ScrollView>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  eyebrow: { ...typography.caption, letterSpacing: 1.2, fontWeight: '800' },
  title: { ...typography.display, fontSize: 30, marginTop: 1, marginBottom: spacing.md },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    height: 50,
  },
  input: { flex: 1, ...typography.body, fontSize: 15, paddingVertical: 0 },
  clear: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultsRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  resultsTitle: { ...typography.heading, fontSize: 18 },
  resultsSub: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  aiBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  aiBadgeText: { ...typography.caption, fontWeight: '700' },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tryTitle: { ...typography.subheading, marginBottom: 10 },
  recentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    paddingVertical: 11,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  recentIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  recentText: { ...typography.body, flex: 1 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  tipCard: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    borderRadius: radius.xl,
    marginTop: spacing.xxl,
    alignItems: 'flex-start',
  },
  tipIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipTitle: { color: '#FFFFFF', fontSize: 14.5, fontWeight: '800' },
  tipText: { color: 'rgba(255,255,255,0.72)', fontSize: 11.5, fontWeight: '500', lineHeight: 17, marginTop: 3 },
});
