import { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Bell,
  Check,
  ChevronRight,
  Cloud,
  Crown,
  Database,
  FolderHeart,
  HelpCircle,
  Heart,
  Images,
  Lock,
  LogOut,
  Monitor,
  Moon,
  Palette,
  RotateCcw,
  Sparkles,
  Sun,
  UserRound,
} from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { Avatar } from '@/components/Avatar';
import { Segmented } from '@/components/Segmented';
import { Sheet } from '@/components/Sheet';
import { SettingRow } from '@/components/SettingRow';
import { useGallery, usePalette } from '@/lib/store';
import { formatBytes, formatCount } from '@/lib/utils';
import { radius, spacing, typography, type ThemeMode } from '@/constants/theme';
import type { Settings } from '@/types';

const themeOptions: Array<{ key: ThemeMode; label: string }> = [
  { key: 'system', label: 'System' },
  { key: 'light', label: 'Light' },
  { key: 'dark', label: 'Dark' },
];

const densityOptions: Array<{ key: Settings['density']; label: string }> = [
  { key: 'comfortable', label: 'Comfortable' },
  { key: 'compact', label: 'Compact' },
];

const storageColors = ['#8B6BFF', '#FF5C8A', '#FFC24B', '#3DDC97', '#2E7BFF', '#21D4C4', '#FF7A59'];

export default function ProfileScreen() {
  const palette = usePalette();
  const { stats, settings, updateSettings, resetData, userAlbums, favorites } = useGallery();
  const [resetOpen, setResetOpen] = useState(false);
  const [proOpen, setProOpen] = useState(false);

  const topCategories = useMemo(() => stats.categoryCounts.slice(0, 5), [stats.categoryCounts]);
  const totalCount = stats.totalPhotos || 1;
  const storageBudget = 15 * 1024 * 1024 * 1024;
  const usedRatio = Math.min(stats.storageBytes / storageBudget, 1);

  return (
    <Screen>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={[styles.topBar, { paddingHorizontal: spacing.lg }]}>
          <View>
            <Text style={[styles.eyebrow, { color: palette.textMuted }]}>YOUR SPACE</Text>
            <Text style={[styles.title, { color: palette.text }]}>You</Text>
          </View>
          <View style={[styles.planPill, { backgroundColor: palette.primarySoft }]}>
            <Sparkles size={12} color={palette.primary} />
            <Text style={[styles.planText, { color: palette.primary }]}>Free plan</Text>
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg }}>
          <View style={[styles.profileCard, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <LinearGradient
              colors={['rgba(139,107,255,0.22)', 'rgba(255,92,138,0.06)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.profileRow}>
              <Avatar name="Alex Rivera" size={64} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.name, { color: palette.text }]}>Alex Rivera</Text>
                <Text style={[styles.handle, { color: palette.textMuted }]}>@alexrivera · Member since 2024</Text>
                <View style={styles.badgeRow}>
                  <View style={[styles.miniBadge, { backgroundColor: palette.surfaceAlt }]}>
                    <Text style={[styles.miniBadgeText, { color: palette.textSecondary }]}>Explorer</Text>
                  </View>
                  <View style={[styles.miniBadge, { backgroundColor: palette.surfaceAlt }]}>
                    <Text style={[styles.miniBadgeText, { color: palette.textSecondary }]}>Curator</Text>
                  </View>
                </View>
              </View>
            </View>

            <View style={[styles.profileStats, { borderTopColor: palette.border }]}>
              <View style={styles.profileStat}>
                <Text style={[styles.profileStatValue, { color: palette.text }]}>{stats.totalPhotos}</Text>
                <Text style={[styles.profileStatLabel, { color: palette.textMuted }]}>Photos</Text>
              </View>
              <View style={[styles.statDivider, { backgroundColor: palette.border }]} />
              <View style={styles.profileStat}>
                <Text style={[styles.profileStatValue, { color: palette.text }]}>{favorites.length}</Text>
                <Text style={[styles.profileStatLabel, { color: palette.textMuted }]}>Favorites</Text>
              </View>
              <View style={[styles.statDivider, { backgroundColor: palette.border }]} />
              <View style={styles.profileStat}>
                <Text style={[styles.profileStatValue, { color: palette.text }]}>{userAlbums.length}</Text>
                <Text style={[styles.profileStatLabel, { color: palette.textMuted }]}>Albums</Text>
              </View>
            </View>
          </View>

          <Pressable onPress={() => setProOpen(true)} style={{ marginTop: spacing.md }}>
            <LinearGradient
              colors={['#2B1B63', '#5C2A8A', '#8E3B72']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.proCard}
            >
              <View style={styles.proIcon}>
                <Crown size={20} color="#FFD479" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.proTitle}>Unlock XPhotos Pro</Text>
                <Text style={styles.proSub}>AI search · 8K exports · unlimited backup</Text>
              </View>
              <ChevronRight size={18} color="rgba(255,255,255,0.8)" />
            </LinearGradient>
          </Pressable>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <Text style={[styles.sectionLabel, { color: palette.textMuted }]}>STORAGE INSIGHTS</Text>
          <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <View style={styles.storageHead}>
              <View style={[styles.storageIcon, { backgroundColor: palette.primarySoft }]}>
                <Database size={18} color={palette.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.storageTitle, { color: palette.text }]}>
                  {formatBytes(stats.storageBytes)} of 15 GB used
                </Text>
                <Text style={[styles.storageSub, { color: palette.textMuted }]}>
                  {(usedRatio * 100).toFixed(1)}% of your storage · {formatCount(stats.totalPhotos)} photos
                </Text>
              </View>
            </View>

            <View style={[styles.storageBar, { backgroundColor: palette.surfaceAlt }]}>
              {topCategories.map((entry, index) => (
                <View
                  key={entry.category}
                  style={{
                    flex: entry.count / totalCount,
                    backgroundColor: storageColors[index % storageColors.length],
                  }}
                />
              ))}
              <View style={{ flex: Math.max(0.02, 1 - topCategories.reduce((acc, c) => acc + c.count / totalCount, 0)) }} />
            </View>

            <View style={styles.legendGrid}>
              {topCategories.map((entry, index) => (
                <View key={entry.category} style={styles.legendItem}>
                  <View style={[styles.legendDot, { backgroundColor: storageColors[index % storageColors.length] }]} />
                  <Text style={[styles.legendLabel, { color: palette.textSecondary }]}>{entry.category}</Text>
                  <Text style={[styles.legendValue, { color: palette.textMuted }]}>{entry.count}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <Text style={[styles.sectionLabel, { color: palette.textMuted }]}>APPEARANCE</Text>
          <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <View style={styles.preferenceRow}>
              <View style={styles.prefLabelRow}>
                <Palette size={16} color={palette.textSecondary} />
                <Text style={[styles.prefLabel, { color: palette.text }]}>Theme</Text>
              </View>
              <Segmented
                options={themeOptions}
                value={settings.themeMode}
                onChange={(key) => updateSettings({ themeMode: key as ThemeMode })}
              />
            </View>
            <View style={[styles.prefDivider, { backgroundColor: palette.border }]} />
            <View style={styles.preferenceRow}>
              <View style={styles.prefLabelRow}>
                <Images size={16} color={palette.textSecondary} />
                <Text style={[styles.prefLabel, { color: palette.text }]}>Grid density</Text>
              </View>
              <Segmented
                options={densityOptions}
                value={settings.density}
                onChange={(key) => updateSettings({ density: key as Settings['density'] })}
              />
            </View>
            <View style={[styles.prefDivider, { backgroundColor: palette.border }]} />
            <SettingRow
              icon={Sparkles}
              title="Autoplay slideshows"
              subtitle="Start playing memories automatically"
              toggle
              value={settings.autoplay ? 'on' : 'off'}
              onToggle={(next) => updateSettings({ autoplay: next })}
            />
            <SettingRow
              icon={UserRound}
              title="Show photo metadata"
              subtitle="Display camera and date details in viewer"
              toggle
              value={settings.showMeta ? 'on' : 'off'}
              onToggle={(next) => updateSettings({ showMeta: next })}
              last
            />
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <Text style={[styles.sectionLabel, { color: palette.textMuted }]}>ACCOUNT & SYNC</Text>
          <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <SettingRow icon={Cloud} title="Cloud sync" subtitle="Keep your library in sync" value="On" onPress={() => setProOpen(true)} />
            <SettingRow icon={FolderHeart} title="Shared albums" subtitle="Collaborate with friends and family" value={`${userAlbums.length} active`} onPress={() => {}} />
            <SettingRow icon={Bell} title="Notifications" subtitle="Memories, shares and reminders" value="Daily" onPress={() => {}} />
            <SettingRow icon={Lock} title="Privacy & security" subtitle="Face ID lock, hidden photos" value="On" onPress={() => {}} />
            <SettingRow icon={HelpCircle} title="Help & support" subtitle="Guides, shortcuts and contact" onPress={() => {}} />
            <SettingRow icon={Heart} title="Rate XPhotos" subtitle="It helps us keep building" onPress={() => {}} last />
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <Text style={[styles.sectionLabel, { color: palette.textMuted }]}>DATA</Text>
          <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <SettingRow
              icon={RotateCcw}
              title="Reset library"
              subtitle="Clear favorites, albums and settings"
              onPress={() => setResetOpen(true)}
              danger
            />
            <SettingRow icon={LogOut} title="Sign out" subtitle="Alex Rivera · alex@xphotos.app" onPress={() => {}} danger last />
          </View>
        </View>

        <View style={styles.footer}>
          <View style={styles.themeIcons}>
            <Sun size={13} color={palette.textMuted} />
            <Monitor size={13} color={palette.textMuted} />
            <Moon size={13} color={palette.textMuted} />
          </View>
          <Text style={[styles.footerText, { color: palette.textMuted }]}>XPhotos 1.0.0 · Crafted for your memories</Text>
        </View>
      </ScrollView>

      <Sheet visible={resetOpen} onClose={() => setResetOpen(false)} title="Reset library?">
        <Text style={[styles.sheetText, { color: palette.textMuted }]}>
          This clears favorites, albums, camera captures and preferences stored on this device. Your original photos stay untouched.
        </Text>
        <View style={styles.sheetActions}>
          <Pressable
            onPress={() => setResetOpen(false)}
            style={[styles.secondaryButton, { borderColor: palette.border }]}
          >
            <Text style={[styles.secondaryText, { color: palette.text }]}>Cancel</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              resetData();
              setResetOpen(false);
            }}
            style={[styles.primaryButton, { backgroundColor: palette.danger }]}
          >
            <Text style={[styles.primaryText, { color: '#FFFFFF' }]}>Reset</Text>
          </Pressable>
        </View>
      </Sheet>

      <Sheet visible={proOpen} onClose={() => setProOpen(false)} title="XPhotos Pro" scroll>
        <LinearGradient
          colors={['#2B1B63', '#5C2A8A', '#8E3B72']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.proSheet}
        >
          <Crown size={26} color="#FFD479" />
          <Text style={styles.proSheetTitle}>Your memories, unlimited</Text>
          <Text style={styles.proSheetSub}>Everything in Free, plus:</Text>
          {[
            'Unlimited original-quality cloud backup',
            'AI search by face, place and object',
            '8K export and RAW editing',
            'Private shared albums with collaborators',
          ].map((feature) => (
            <View key={feature} style={styles.proFeature}>
              <Check size={14} color="#3DDC97" />
              <Text style={styles.proFeatureText}>{feature}</Text>
            </View>
          ))}
          <View style={styles.proPriceRow}>
            <Text style={styles.proPrice}>$4.99</Text>
            <Text style={styles.proPriceSub}>/ month · cancel anytime</Text>
          </View>
          <Pressable
            onPress={() => setProOpen(false)}
            style={({ pressed }) => [styles.proButton, { opacity: pressed ? 0.85 : 1 }]}
          >
            <Text style={styles.proButtonText}>Join the waitlist</Text>
          </Pressable>
        </LinearGradient>
        <Text style={[styles.sheetText, { color: palette.textMuted, marginTop: spacing.md, textAlign: 'center' }]}>
          Pro is rolling out gradually. You are on the list.
        </Text>
      </Sheet>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: spacing.lg,
  },
  eyebrow: { ...typography.caption, letterSpacing: 1.2, fontWeight: '800' },
  title: { ...typography.display, fontSize: 30, marginTop: 1 },
  planPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: radius.pill,
    marginTop: 6,
  },
  planText: { ...typography.caption, fontWeight: '800' },
  profileCard: {
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
    padding: spacing.lg,
  },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  name: { ...typography.heading, fontSize: 21 },
  handle: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  badgeRow: { flexDirection: 'row', gap: 6, marginTop: 7 },
  miniBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill },
  miniBadgeText: { fontSize: 9.5, fontWeight: '700', letterSpacing: 0.3 },
  profileStats: { flexDirection: 'row', alignItems: 'center', borderTopWidth: StyleSheet.hairlineWidth, marginTop: spacing.lg, paddingTop: spacing.md },
  profileStat: { flex: 1, alignItems: 'center' },
  profileStatValue: { ...typography.heading, fontSize: 19 },
  profileStatLabel: { ...typography.caption, marginTop: 1, fontWeight: '500' },
  statDivider: { width: StyleSheet.hairlineWidth, height: 26 },
  proCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 15,
    borderRadius: radius.xl,
  },
  proIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proTitle: { color: '#FFFFFF', fontSize: 14.5, fontWeight: '800' },
  proSub: { color: 'rgba(255,255,255,0.72)', fontSize: 11, fontWeight: '500', marginTop: 2 },
  sectionLabel: { ...typography.caption, letterSpacing: 1, fontWeight: '800', marginBottom: 8, marginLeft: 2 },
  card: {
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: spacing.lg,
    paddingVertical: 4,
  },
  storageHead: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: spacing.md },
  storageIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  storageTitle: { ...typography.body, fontWeight: '700' },
  storageSub: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  storageBar: { flexDirection: 'row', height: 10, borderRadius: 5, overflow: 'hidden', marginTop: spacing.md, gap: 2 },
  legendGrid: { flexDirection: 'row', flexWrap: 'wrap', marginTop: spacing.md, paddingBottom: spacing.md, rowGap: 6 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6, width: '50%' },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { ...typography.caption, fontWeight: '600', flex: 1 },
  legendValue: { ...typography.caption, fontWeight: '700', marginRight: 8 },
  preferenceRow: { gap: 10, paddingVertical: 12 },
  prefLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  prefLabel: { ...typography.body, fontWeight: '600' },
  prefDivider: { height: StyleSheet.hairlineWidth },
  footer: { alignItems: 'center', marginTop: spacing.xxl, gap: 6 },
  themeIcons: { flexDirection: 'row', gap: 8 },
  footerText: { ...typography.caption, fontWeight: '500' },
  sheetText: { ...typography.small, lineHeight: 20 },
  sheetActions: { flexDirection: 'row', gap: 10, marginTop: spacing.lg },
  primaryButton: { flex: 1, alignItems: 'center', paddingVertical: 14, borderRadius: radius.lg },
  primaryText: { ...typography.body, fontWeight: '700' },
  secondaryButton: { flex: 1, alignItems: 'center', paddingVertical: 14, borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth },
  secondaryText: { ...typography.body, fontWeight: '700' },
  proSheet: { borderRadius: radius.xl, padding: spacing.lg, gap: 8 },
  proSheetTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  proSheetSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12, fontWeight: '500', marginBottom: 2 },
  proFeature: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 2 },
  proFeatureText: { color: 'rgba(255,255,255,0.9)', fontSize: 12.5, fontWeight: '500', flex: 1 },
  proPriceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 6, marginTop: 10 },
  proPrice: { color: '#FFFFFF', fontSize: 28, fontWeight: '800' },
  proPriceSub: { color: 'rgba(255,255,255,0.65)', fontSize: 11.5, fontWeight: '500' },
  proButton: { backgroundColor: '#FFD479', borderRadius: radius.lg, paddingVertical: 13, alignItems: 'center', marginTop: 8 },
  proButtonText: { color: '#2B1B63', fontSize: 13.5, fontWeight: '800' },
});
