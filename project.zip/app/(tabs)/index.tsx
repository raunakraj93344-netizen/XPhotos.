import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ArrowDownUp,
  Camera,
  Check,
  ChevronDown,
  FolderPlus,
  Grid2x2,
  Heart,
  Images,
  Layers,
  LayoutGrid,
  Play,
  Search,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { Brand } from '@/components/Brand';
import { Chip } from '@/components/Chip';
import { IconButton } from '@/components/IconButton';
import { StatTile } from '@/components/StatTile';
import { Sheet } from '@/components/Sheet';
import { EmptyState } from '@/components/EmptyState';
import { MemoryCard, ProBanner } from '@/components/cards';
import { MasonryGrid, PhotoGrid } from '@/components/PhotoGrid';
import { useGallery, usePalette } from '@/lib/store';
import { categories } from '@/data/photos';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';
import type { Photo } from '@/types';

const sortLabels: Record<string, string> = {
  newest: 'Newest first',
  oldest: 'Oldest first',
  az: 'Title A–Z',
  category: 'By category',
};

const sortDescriptions: Record<string, string> = {
  newest: 'Most recent memories at the top',
  oldest: 'Travel back to where it started',
  az: 'Alphabetical by photo title',
  category: 'Grouped by subject',
};

export default function LibraryScreen() {
  const router = useRouter();
  const palette = usePalette();
  const {
    photos,
    stats,
    favorites,
    settings,
    hydrated,
    userAlbums,
    toggleFavorite,
    addPhotosToAlbum,
    deletePhotos,
    updateSettings,
  } = useGallery();

  const [filter, setFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'masonry' | 'grid'>('masonry');
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [sortOpen, setSortOpen] = useState(false);
  const [albumOpen, setAlbumOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const favoriteSet = useMemo(() => new Set(favorites), [favorites]);

  const filtered = useMemo(() => {
    let list = photos;
    if (filter === 'favorites') list = list.filter((p) => favoriteSet.has(p.id));
    else if (filter === 'recent') list = list.slice(0, 30);
    else if (filter !== 'all') list = list.filter((p) => p.category === filter);

    if (settings.sort === 'oldest') {
      list = [...list].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    } else if (settings.sort === 'az') {
      list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    } else if (settings.sort === 'category') {
      list = [...list].sort((a, b) => a.category.localeCompare(b.category));
    }
    return list;
  }, [photos, filter, favoriteSet, settings.sort]);

  const selectedPhotos = useMemo(
    () => photos.filter((p) => selectedIds.includes(p.id)),
    [photos, selectedIds]
  );

  const memoryPhoto = photos[3] ?? photos[0];

  const enterSelection = (photo: Photo) => {
    tapFeedback();
    setSelectionMode(true);
    setSelectedIds([photo.id]);
  };

  const toggleSelected = (photo: Photo) => {
    tapFeedback();
    setSelectedIds((prev) =>
      prev.includes(photo.id) ? prev.filter((id) => id !== photo.id) : [...prev, photo.id]
    );
  };

  const exitSelection = () => {
    setSelectionMode(false);
    setSelectedIds([]);
  };

  const handlePhotoPress = (photo: Photo) => {
    if (selectionMode) {
      toggleSelected(photo);
      return;
    }
    router.push(`/photo/${photo.id}`);
  };

  const bulkFavorite = () => {
    const allFav = selectedPhotos.every((p) => favoriteSet.has(p.id));
    selectedPhotos.forEach((p) => {
      if (allFav ? favoriteSet.has(p.id) : !favoriteSet.has(p.id)) toggleFavorite(p.id);
    });
    successFeedback();
    exitSelection();
  };

  const confirmDelete = () => {
    deletePhotos(selectedIds);
    setDeleteOpen(false);
    exitSelection();
  };

  const chips = [
    { key: 'all', label: 'All' },
    { key: 'favorites', label: `Favorites` },
    { key: 'recent', label: 'Recent' },
    ...categories.map((c) => ({ key: c, label: c })),
  ];

  const galleryHeader = (
    <View>
      <View style={{ paddingHorizontal: spacing.lg }}>
        <MemoryCard
          uri={memoryPhoto?.thumb ?? ''}
          count={12}
          onPress={() => router.push('/album/recent')}
          onReplay={() => router.push(`/slideshow?start=${memoryPhoto?.id ?? ''}`)}
        />
      </View>

      <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.lg }}>
        <Pressable
          onPress={() => router.push('/search')}
          style={[styles.searchBar, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}
        >
          <Search size={17} color={palette.textMuted} />
          <Text style={[styles.searchPlaceholder, { color: palette.textMuted }]}>
            Search photos, places, people…
          </Text>
          <View style={[styles.searchBadge, { backgroundColor: palette.surface }]}>
            <Sparkles size={12} color={palette.primary} />
          </View>
        </Pressable>
      </View>

      <View style={[styles.statsRow, { paddingHorizontal: spacing.lg }]}>
        <StatTile
          icon={Images}
          label="Photos"
          value={`${stats.totalPhotos}`}
          onPress={() => router.push('/album/all')}
        />
        <StatTile
          icon={Heart}
          label="Favorites"
          value={`${stats.favorites}`}
          tint={palette.accent}
          onPress={() => router.push('/album/favorites')}
        />
        <StatTile
          icon={Layers}
          label="Albums"
          value={`${stats.albums}`}
          tint={palette.success}
          onPress={() => router.push('/albums')}
        />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipsRow}
      >
        {chips.map((chip) => (
          <Chip
            key={chip.key}
            label={chip.label}
            active={filter === chip.key}
            onPress={() => {
              tapFeedback();
              setFilter(chip.key);
            }}
            size="sm"
          />
        ))}
      </ScrollView>

      <View style={[styles.sectionRow, { paddingHorizontal: spacing.lg }]}>
        <View>
          <Text style={[styles.sectionTitle, { color: palette.text }]}>
            {filter === 'all' ? 'Your gallery' : filter === 'favorites' ? 'Favorites' : filter === 'recent' ? 'Recent' : filter}
          </Text>
          <Text style={[styles.sectionCount, { color: palette.textMuted }]}>
            {filtered.length} {filtered.length === 1 ? 'photo' : 'photos'}
          </Text>
        </View>
        <View style={styles.sectionActions}>
          <Pressable
            onPress={() => setSortOpen(true)}
            style={[styles.sortButton, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}
          >
            <ArrowDownUp size={13} color={palette.textSecondary} />
            <Text style={[styles.sortText, { color: palette.textSecondary }]}>
              {sortLabels[settings.sort]}
            </Text>
            <ChevronDown size={13} color={palette.textMuted} />
          </Pressable>
          <View style={[styles.viewToggle, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}>
            <Pressable
              onPress={() => setViewMode('masonry')}
              style={[styles.viewButton, viewMode === 'masonry' && { backgroundColor: palette.surface }]}
            >
              <LayoutGrid size={15} color={viewMode === 'masonry' ? palette.text : palette.textMuted} />
            </Pressable>
            <Pressable
              onPress={() => setViewMode('grid')}
              style={[styles.viewButton, viewMode === 'grid' && { backgroundColor: palette.surface }]}
            >
              <Grid2x2 size={15} color={viewMode === 'grid' ? palette.text : palette.textMuted} />
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );

  const empty = (
    <EmptyState
      icon={filter === 'favorites' ? Heart : Images}
      title={filter === 'favorites' ? 'No favorites yet' : 'Nothing here yet'}
      message={
        filter === 'favorites'
          ? 'Tap the heart on any photo to keep it close. Your favorites live here.'
          : 'Photos you add will appear here. Try another filter or capture something new.'
      }
      actionLabel="Open camera"
      onAction={() => router.push('/camera')}
    />
  );

  if (!hydrated) {
    return (
      <Screen>
        <View style={styles.loading}>
          <ActivityIndicator color={palette.primary} size="large" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      {selectionMode ? (
        <View style={[styles.selectionBar, { borderBottomColor: palette.border }]}>
          <IconButton
            icon={<X size={19} color={palette.text} />}
            size={34}
            variant="ghost"
            onPress={exitSelection}
            accessibilityLabel="Exit selection"
          />
          <Text style={[styles.selectionCount, { color: palette.text }]}>
            {selectedIds.length} selected
          </Text>
          <Pressable
            onPress={() =>
              setSelectedIds(selectedIds.length === filtered.length ? [] : filtered.map((p) => p.id))
            }
            style={[styles.selectAll, { backgroundColor: palette.surfaceAlt }]}
          >
            <Text style={[styles.selectAllText, { color: palette.textSecondary }]}>
              {selectedIds.length === filtered.length ? 'None' : 'All'}
            </Text>
          </Pressable>
          <View style={{ flex: 1 }} />
          <IconButton
            icon={<Heart size={18} color={palette.text} />}
            size={34}
            variant="ghost"
            onPress={bulkFavorite}
            accessibilityLabel="Toggle favorite"
          />
          <IconButton
            icon={<FolderPlus size={18} color={palette.text} />}
            size={34}
            variant="ghost"
            onPress={() => setAlbumOpen(true)}
            accessibilityLabel="Add to album"
          />
          <IconButton
            icon={<Trash2 size={18} color={palette.danger} />}
            size={34}
            variant="ghost"
            onPress={() => setDeleteOpen(true)}
            accessibilityLabel="Delete"
          />
        </View>
      ) : (
        <View style={[styles.topBar, { paddingHorizontal: spacing.lg }]}>
          <Brand />
          <View style={styles.topActions}>
            <IconButton
              icon={<Play size={17} color={palette.text} />}
              onPress={() => router.push(`/slideshow?start=${photos[0]?.id ?? ''}`)}
              accessibilityLabel="Play slideshow"
            />
            <Pressable onPress={() => router.push('/profile')}>
              <LinearGradient
                colors={['#7C5CFF', '#C05CFF']}
                style={[styles.proAvatar, { borderColor: palette.border }]}
              >
                <Text style={styles.proAvatarText}>AR</Text>
              </LinearGradient>
            </Pressable>
          </View>
        </View>
      )}

      {viewMode === 'masonry' ? (
        <MasonryGrid
          photos={filtered}
          onPressPhoto={handlePhotoPress}
          onLongPressPhoto={enterSelection}
          selectionMode={selectionMode}
          selectedIds={selectedIds}
          favorites={favorites}
          header={galleryHeader}
          empty={empty}
          footer={
            <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xl }}>
              <ProBanner onPress={() => router.push('/profile')} />
              <Text style={[styles.footerNote, { color: palette.textMuted }]}>
                {stats.totalPhotos} photos · {userAlbums.length} albums · synced just now
              </Text>
            </View>
          }
        />
      ) : (
        <PhotoGrid
          photos={filtered}
          onPressPhoto={handlePhotoPress}
          onLongPressPhoto={enterSelection}
          selectionMode={selectionMode}
          selectedIds={selectedIds}
          favorites={favorites}
          header={galleryHeader}
          empty={empty}
          bleedHeader
          footer={
            <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xl }}>
              <ProBanner onPress={() => router.push('/profile')} />
            </View>
          }
        />
      )}

      {!selectionMode ? (
        <Pressable
          onPress={() => router.push('/camera')}
          style={styles.fabWrap}
        >
          <LinearGradient
            colors={['#7C5CFF', '#C05CFF']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.fab}
          >
            <Camera size={23} color="#FFFFFF" strokeWidth={2.2} />
          </LinearGradient>
        </Pressable>
      ) : null}

      <Sheet visible={sortOpen} onClose={() => setSortOpen(false)} title="Sort photos">
        {(['newest', 'oldest', 'az', 'category'] as const).map((key) => (
          <Pressable
            key={key}
            onPress={() => {
              updateSettings({ sort: key });
              setSortOpen(false);
            }}
            style={styles.sheetRow}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.sheetTitle, { color: palette.text }]}>{sortLabels[key]}</Text>
              <Text style={[styles.sheetSub, { color: palette.textMuted }]}>{sortDescriptions[key]}</Text>
            </View>
            {settings.sort === key ? <Check size={18} color={palette.primary} /> : null}
          </Pressable>
        ))}
      </Sheet>

      <Sheet visible={albumOpen} onClose={() => setAlbumOpen(false)} title="Add to album" scroll>
        {userAlbums.length === 0 ? (
          <View style={{ paddingBottom: 16 }}>
            <Text style={[styles.sheetSub, { color: palette.textMuted, marginBottom: 14 }]}>
              You do not have any albums yet. Create one to start curating.
            </Text>
            <Pressable
              onPress={() => {
                setAlbumOpen(false);
                exitSelection();
                router.push('/albums');
              }}
              style={[styles.primaryButton, { backgroundColor: palette.text }]}
            >
              <Text style={[styles.primaryButtonText, { color: palette.bg }]}>Go to albums</Text>
            </Pressable>
          </View>
        ) : (
          userAlbums.map((album) => (
            <Pressable
              key={album.id}
              onPress={() => {
                addPhotosToAlbum(album.id, selectedIds);
                successFeedback();
                setAlbumOpen(false);
                exitSelection();
              }}
              style={styles.sheetRow}
            >
              <Text style={{ fontSize: 22 }}>{album.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sheetTitle, { color: palette.text }]}>{album.title}</Text>
                <Text style={[styles.sheetSub, { color: palette.textMuted }]}>
                  {album.photoIds.length} photos
                </Text>
              </View>
              <FolderPlus size={17} color={palette.textMuted} />
            </Pressable>
          ))
        )}
      </Sheet>

      <Sheet visible={deleteOpen} onClose={() => setDeleteOpen(false)} title={`Delete ${selectedIds.length} photos?`}>
        <Text style={[styles.sheetSub, { color: palette.textMuted, marginBottom: 18 }]}>
          This removes the selected photos from your XPhotos library. This cannot be undone.
        </Text>
        <View style={styles.sheetActions}>
          <Pressable
            onPress={() => setDeleteOpen(false)}
            style={[styles.secondaryButton, { borderColor: palette.border }]}
          >
            <Text style={[styles.secondaryButtonText, { color: palette.text }]}>Cancel</Text>
          </Pressable>
          <Pressable onPress={confirmDelete} style={[styles.primaryButton, { backgroundColor: palette.danger }]}>
            <Text style={[styles.primaryButtonText, { color: '#FFFFFF' }]}>Delete</Text>
          </Pressable>
        </View>
      </Sheet>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
  },
  topActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  proAvatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
  },
  proAvatarText: { color: '#FFFFFF', fontSize: 13, fontWeight: '800' },
  selectionBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 8,
    paddingBottom: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  selectionCount: { ...typography.subheading, fontSize: 15, marginLeft: 4 },
  selectAll: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, marginLeft: 8 },
  selectAllText: { ...typography.caption, fontWeight: '700' },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    height: 46,
  },
  searchPlaceholder: { ...typography.body, flex: 1, fontSize: 14 },
  searchBadge: {
    width: 26,
    height: 26,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: spacing.lg },
  chipsRow: { paddingHorizontal: spacing.lg, gap: 8, paddingVertical: spacing.lg },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 8,
  },
  sectionTitle: { ...typography.heading },
  sectionCount: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  sectionActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  sortText: { ...typography.caption, fontWeight: '600' },
  viewToggle: {
    flexDirection: 'row',
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 3,
    gap: 2,
  },
  viewButton: {
    width: 28,
    height: 26,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabWrap: { position: 'absolute', right: 20, bottom: 24 },
  fab: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 10,
  },
  footerNote: { ...typography.caption, textAlign: 'center', marginTop: 16, fontWeight: '500' },
  sheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
  },
  sheetTitle: { ...typography.body, fontWeight: '700' },
  sheetSub: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  sheetActions: { flexDirection: 'row', gap: 10, marginBottom: 4 },
  primaryButton: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: radius.lg },
  primaryButtonText: { ...typography.body, fontWeight: '700' },
  secondaryButton: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth },
  secondaryButtonText: { ...typography.body, fontWeight: '700' },
});
