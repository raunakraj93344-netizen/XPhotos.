import { useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import {
  Camera,
  Clock,
  FolderHeart,
  Heart,
  Images,
  Plus,
  Sparkles,
} from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { IconButton } from '@/components/IconButton';
import { SectionHeader } from '@/components/SectionHeader';
import { Sheet } from '@/components/Sheet';
import { EmptyState } from '@/components/EmptyState';
import { AlbumCard, CollectionCard } from '@/components/cards';
import { useGallery, usePalette } from '@/lib/store';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';

const emojiChoices = ['📸', '🌟', '🌊', '🏔️', '🍜', '🐾', '🎨', '🚗', '🎉', '🌇', '💜', '🧳'];

export default function AlbumsScreen() {
  const router = useRouter();
  const palette = usePalette();
  const { width } = useWindowDimensions();
  const { userAlbums, stats, photos, favorites, getPhoto, curated, createAlbum } = useGallery();

  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [emoji, setEmoji] = useState(emojiChoices[0]);

  const cardWidth = (width - spacing.lg * 2 - 10) / 2;
  const smartWidth = 148;

  const smartAlbums = [
    {
      id: 'favorites',
      title: 'Favorites',
      count: favorites.length,
      emoji: '❤️',
      icon: Heart,
      uri: favorites.length > 0 ? getPhoto(favorites[0])?.thumb : photos[0]?.thumb,
    },
    {
      id: 'recent',
      title: 'Recently Added',
      count: Math.min(photos.length, 30),
      emoji: '🕒',
      icon: Clock,
      uri: photos[0]?.thumb,
    },
    {
      id: 'camera',
      title: 'Camera Roll',
      count: photos.filter((p) => p.isCustom).length,
      emoji: '📷',
      icon: Camera,
      uri: photos.find((p) => p.isCustom)?.thumb,
    },
    {
      id: 'all',
      title: 'All Photos',
      count: photos.length,
      emoji: '🗂️',
      icon: Images,
      uri: photos[1]?.thumb,
    },
  ];

  const handleCreate = () => {
    const id = createAlbum(name, emoji);
    successFeedback();
    setCreateOpen(false);
    setName('');
    setEmoji(emojiChoices[0]);
    router.push(`/album/${id}`);
  };

  return (
    <Screen>
      <View style={[styles.topBar, { paddingHorizontal: spacing.lg }]}>
        <View>
          <Text style={[styles.eyebrow, { color: palette.textMuted }]}>CURATE YOUR WORLD</Text>
          <Text style={[styles.title, { color: palette.text }]}>Albums</Text>
          <Text style={[styles.subtitle, { color: palette.textMuted }]}>
            {userAlbums.length} albums · {stats.totalPhotos} photos in your library
          </Text>
        </View>
        <IconButton
          icon={<Plus size={20} color={palette.bg} />}
          variant="solid"
          onPress={() => {
            tapFeedback();
            setCreateOpen(true);
          }}
          accessibilityLabel="Create album"
        />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.sm }}>
          <SectionHeader title="Smart albums" subtitle="Automatically kept up to date" />
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: 10 }}
        >
          {smartAlbums.map((album) => (
            <AlbumCard
              key={album.id}
              title={album.title}
              count={album.count}
              uri={album.uri}
              emoji={album.emoji}
              width={smartWidth}
              height={112}
              gradient={album.id === 'favorites' ? 'candy' : album.id === 'recent' ? 'ocean' : album.id === 'camera' ? 'graphite' : 'violet'}
              onPress={() => router.push(`/album/${album.id}`)}
            />
          ))}
        </ScrollView>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <SectionHeader
            title="My albums"
            subtitle="Hand-curated collections"
            actionLabel="New"
            onAction={() => setCreateOpen(true)}
          />
          {userAlbums.length === 0 ? (
            <View style={[styles.emptyWrap, { backgroundColor: palette.surface, borderColor: palette.border }]}>
              <EmptyState
                icon={FolderHeart}
                title="No albums yet"
                message="Group your favorite moments into albums — trips, people, projects, anything."
                actionLabel="Create your first album"
                onAction={() => setCreateOpen(true)}
              />
            </View>
          ) : (
            <View style={styles.albumGrid}>
              {userAlbums.map((album) => {
                const cover = album.photoIds.length > 0 ? getPhoto(album.photoIds[0]) : undefined;
                return (
                  <AlbumCard
                    key={album.id}
                    title={album.title}
                    count={album.photoIds.length}
                    uri={cover?.thumb}
                    emoji={album.emoji}
                    width={cardWidth}
                    height={140}
                    onPress={() => router.push(`/album/${album.id}`)}
                  />
                );
              })}
            </View>
          )}
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <SectionHeader
            title="Editorial collections"
            subtitle="Start from an expertly crafted set"
            actionLabel="Discover"
            onAction={() => router.push('/discover')}
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12 }}>
            {curated.slice(0, 6).map((album) => (
              <CollectionCard
                key={album.id}
                title={album.title}
                subtitle={`${album.photoIds.length} photos · ${album.subtitle}`}
                uri={getPhoto(album.photoIds[0])?.thumb}
                gradient={album.gradient}
                width={190}
                height={130}
                onPress={() => router.push(`/collection/${album.id}`)}
              />
            ))}
          </ScrollView>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xxl }}>
          <View style={[styles.tipCard, { backgroundColor: palette.surface, borderColor: palette.border }]}>
            <View style={[styles.tipIcon, { backgroundColor: palette.primarySoft }]}>
              <Sparkles size={17} color={palette.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.tipTitle, { color: palette.text }]}>Long-press any photo</Text>
              <Text style={[styles.tipText, { color: palette.textMuted }]}>
                Select multiple shots in your library, then add them to an album in one tap.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>

      <Sheet visible={createOpen} onClose={() => setCreateOpen(false)} title="Create album">
        <Text style={[styles.fieldLabel, { color: palette.textMuted }]}>ALBUM NAME</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="e.g. Summer in Lisbon"
          placeholderTextColor={palette.textMuted}
          style={[
            styles.input,
            { backgroundColor: palette.surfaceAlt, borderColor: palette.border, color: palette.text },
          ]}
          autoFocus
          maxLength={40}
        />
        <Text style={[styles.fieldLabel, { color: palette.textMuted, marginTop: spacing.lg }]}>COVER EMOJI</Text>
        <View style={styles.emojiRow}>
          {emojiChoices.map((choice) => (
            <Pressable
              key={choice}
              onPress={() => setEmoji(choice)}
              style={[
                styles.emojiButton,
                {
                  backgroundColor: emoji === choice ? palette.primarySoft : palette.surfaceAlt,
                  borderColor: emoji === choice ? palette.primary : palette.border,
                },
              ]}
            >
              <Text style={{ fontSize: 20 }}>{choice}</Text>
            </Pressable>
          ))}
        </View>
        <Pressable
          onPress={handleCreate}
          style={({ pressed }) => [
            styles.createButton,
            { backgroundColor: palette.text, opacity: pressed ? 0.85 : 1, marginTop: spacing.xl },
          ]}
        >
          <Text style={[styles.createButtonText, { color: palette.bg }]}>Create album</Text>
        </Pressable>
      </Sheet>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: spacing.lg,
    gap: 12,
  },
  eyebrow: { ...typography.caption, letterSpacing: 1.2, fontWeight: '800' },
  title: { ...typography.display, fontSize: 30, marginTop: 1 },
  subtitle: { ...typography.small, marginTop: 3 },
  albumGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  emptyWrap: { borderRadius: radius.xl, borderWidth: StyleSheet.hairlineWidth },
  tipCard: {
    flexDirection: 'row',
    gap: 12,
    padding: 15,
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'flex-start',
  },
  tipIcon: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipTitle: { ...typography.body, fontWeight: '700' },
  tipText: { ...typography.caption, marginTop: 3, lineHeight: 17, fontWeight: '500' },
  fieldLabel: { ...typography.caption, letterSpacing: 0.9, fontWeight: '800', marginBottom: 8 },
  input: {
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    height: 48,
    ...typography.body,
  },
  emojiRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  emojiButton: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
  },
  createButton: { alignItems: 'center', justifyContent: 'center', paddingVertical: 15, borderRadius: radius.lg },
  createButtonText: { ...typography.body, fontWeight: '800' },
});
