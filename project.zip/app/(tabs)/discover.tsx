import { useMemo, useRef, useState } from 'react';
import {
  NativeScrollEvent,
  NativeSyntheticEvent,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowUpRight, Camera, Moon, Palette, Search, Sparkles, Sun, Zap } from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { IconButton } from '@/components/IconButton';
import { SectionHeader } from '@/components/SectionHeader';
import { Chip } from '@/components/Chip';
import { SmartImage } from '@/components/SmartImage';
import { PhotoCard } from '@/components/PhotoCard';
import {
  CategoryCard,
  CollectionCard,
  PhotoOfDayCard,
  ProBanner,
  StoryRing,
} from '@/components/cards';
import { useGallery, usePalette } from '@/lib/store';
import { categories, photoOfTheDayId, stories, trendingSearches } from '@/data/photos';
import { gradients, radius, spacing, typography, type GradientKey } from '@/constants/theme';

const categoryTints: GradientKey[] = [
  'violet',
  'ocean',
  'midnight',
  'ember',
  'sunset',
  'candy',
  'violet',
  'graphite',
  'candy',
];

const moods = [
  { id: 'golden-hour', title: 'Golden', subtitle: 'Warm & dreamy', icon: Sun, gradient: 'ember' as const },
  { id: 'urban-jungle', title: 'Moody', subtitle: 'Dark & cinematic', icon: Moon, gradient: 'midnight' as const },
  { id: 'minimal-forms', title: 'Minimal', subtitle: 'Clean & calm', icon: Palette, gradient: 'violet' as const },
  { id: 'wild-and-free', title: 'Vivid', subtitle: 'Bold & alive', icon: Zap, gradient: 'sunset' as const },
];

export default function DiscoverScreen() {
  const router = useRouter();
  const palette = usePalette();
  const { width } = useWindowDimensions();
  const { photos, curated, getPhoto, stats } = useGallery();
  const [heroIndex, setHeroIndex] = useState(0);
  const heroRef = useRef<ScrollView>(null);

  const heroWidth = width - spacing.lg * 2;
  const heroStride = heroWidth + 12;

  const featured = curated.slice(0, 4);
  const heroPhoto = (albumId: string) => {
    const album = curated.find((a) => a.id === albumId);
    return album ? getPhoto(album.photoIds[0]) : undefined;
  };

  const picks = useMemo(() => photos.filter((_, i) => [12, 5, 33, 20, 48, 41].includes(i)), [photos]);
  const pod = getPhoto(photoOfTheDayId);

  const onHeroScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const next = Math.round(event.nativeEvent.contentOffset.x / heroStride);
    if (next !== heroIndex) setHeroIndex(next);
  };

  const gridCardWidth = (width - spacing.lg * 2 - 10) / 2;

  return (
    <Screen>
      <View style={[styles.topBar, { paddingHorizontal: spacing.lg }]}>
        <View>
          <Text style={[styles.eyebrow, { color: palette.textMuted }]}>CURATED DAILY</Text>
          <Text style={[styles.title, { color: palette.text }]}>Discover</Text>
        </View>
        <View style={styles.topActions}>
          <IconButton
            icon={<Search size={17} color={palette.text} />}
            onPress={() => router.push('/search')}
            accessibilityLabel="Search"
          />
          <IconButton
            icon={<Camera size={17} color={palette.text} />}
            onPress={() => router.push('/camera')}
            accessibilityLabel="Camera"
          />
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <ScrollView
          ref={heroRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          snapToInterval={heroStride}
          snapToAlignment="start"
          onScroll={onHeroScroll}
          scrollEventThrottle={16}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: 12 }}
        >
          {featured.map((album) => {
            const cover = getPhoto(album.photoIds[0]);
            return (
              <Pressable
                key={album.id}
                onPress={() => router.push(`/collection/${album.id}`)}
                style={({ pressed }) => [styles.hero, { width: heroWidth, opacity: pressed ? 0.94 : 1 }]}
              >
                <SmartImage uri={cover?.thumb ?? ''} style={StyleSheet.absoluteFill} radius={radius.xl} />
                <LinearGradient
                  colors={['rgba(0,0,0,0.05)', 'rgba(0,0,0,0.35)', 'rgba(0,0,0,0.9)']}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.heroTop}>
                  <View style={styles.heroBadge}>
                    <Sparkles size={12} color="#FFD479" />
                    <Text style={styles.heroBadgeText}>FEATURED COLLECTION</Text>
                  </View>
                  <View style={styles.heroCount}>
                    <Text style={styles.heroCountText}>{album.photoIds.length} photos</Text>
                  </View>
                </View>
                <View style={styles.heroBottom}>
                  <Text style={styles.heroEmoji}>{album.emoji}</Text>
                  <Text style={styles.heroTitle}>{album.title}</Text>
                  <Text style={styles.heroSub} numberOfLines={2}>
                    {album.description}
                  </Text>
                  <View style={styles.heroCta}>
                    <Text style={styles.heroCtaText}>Explore collection</Text>
                    <ArrowUpRight size={15} color="#0B0B12" />
                  </View>
                </View>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={styles.dots}>
          {featured.map((album, index) => (
            <View
              key={album.id}
              style={[
                styles.dot,
                {
                  width: index === heroIndex ? 20 : 6,
                  backgroundColor: index === heroIndex ? palette.text : palette.borderStrong,
                },
              ]}
            />
          ))}
        </View>

        <View style={styles.section}>
          <SectionHeader title="Stories" subtitle="Bite-sized visual journeys" />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 12 }}
          >
            {stories.map((story) => {
              const cover = getPhoto(story.coverId);
              return (
                <StoryRing
                  key={story.id}
                  title={story.title}
                  uri={cover?.thumb ?? ''}
                  gradient={story.gradient}
                  onPress={() => router.push(`/collection/${story.albumId}`)}
                />
              );
            })}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Curated for you"
            subtitle="Collections picked by our editors"
            actionLabel="See all"
            onAction={() => router.push('/albums')}
          />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 12, paddingRight: spacing.lg }}
          >
            {curated.slice(2).map((album) => (
              <CollectionCard
                key={album.id}
                title={album.title}
                subtitle={album.subtitle}
                uri={getPhoto(album.photoIds[0])?.thumb}
                gradient={album.gradient}
                width={210}
                height={150}
                onPress={() => router.push(`/collection/${album.id}`)}
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeader title="Shop the mood" subtitle="Jump straight into a feeling" />
          <View style={styles.moodGrid}>
            {moods.map((mood) => {
              const Icon = mood.icon;
              return (
                <Pressable
                  key={mood.id}
                  onPress={() => router.push(`/collection/${mood.id}`)}
                  style={({ pressed }) => ({ width: gridCardWidth, opacity: pressed ? 0.88 : 1 })}
                >
                  <LinearGradient
                    colors={gradients[mood.gradient]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.moodCard}
                  >
                    <View style={styles.moodIcon}>
                      <Icon size={18} color="#FFFFFF" />
                    </View>
                    <Text style={styles.moodTitle}>{mood.title}</Text>
                    <Text style={styles.moodSub}>{mood.subtitle}</Text>
                  </LinearGradient>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeader title="Trending searches" subtitle="What everyone is looking for" />
          <View style={styles.tagWrap}>
            {trendingSearches.map((tag) => (
              <Chip
                key={tag}
                label={`#${tag}`}
                onPress={() => router.push({ pathname: '/search', params: { q: tag } })}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeader
            title="Editors' picks"
            subtitle="Standout frames from this week"
            actionLabel="See all"
            onAction={() => router.push('/album/all')}
          />
          <View style={styles.pickGrid}>
            {picks.map((photo) => (
              <PhotoCard
                key={photo.id}
                photo={photo}
                width={gridCardWidth}
                height={150}
                onPress={() => router.push(`/photo/${photo.id}`)}
                showLabel
                radiusValue={radius.lg}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeader title="Photo of the day" subtitle="A single frame worth pausing for" />
          {pod ? (
            <PhotoOfDayCard
              uri={pod.thumb}
              title={pod.title}
              photographer={pod.photographer}
              onPress={() => router.push(`/photo/${pod.id}`)}
            />
          ) : null}
        </View>

        <View style={styles.section}>
          <SectionHeader title="Browse by category" subtitle={`${stats.totalPhotos} photos across ${categories.length} worlds`} />
          <View style={styles.categoryGrid}>
            {categories.map((category, index) => {
              const cover = photos.find((p) => p.category === category);
              const count = photos.filter((p) => p.category === category).length;
              return (
                <CategoryCard
                  key={category}
                  title={category}
                  count={count}
                  uri={cover?.thumb}
                  gradient={categoryTints[index % categoryTints.length]}
                  width={gridCardWidth}
                  onPress={() => router.push({ pathname: '/search', params: { q: category } })}
                />
              );
            })}
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.sm }}>
          <ProBanner onPress={() => router.push('/profile')} />
          <Text style={[styles.footer, { color: palette.textMuted }]}>
            Handpicked by the XPhotos editorial team
          </Text>
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: spacing.md,
  },
  eyebrow: { ...typography.caption, letterSpacing: 1.2, fontWeight: '800' },
  title: { ...typography.display, fontSize: 30, marginTop: 1 },
  topActions: { flexDirection: 'row', gap: 10 },
  hero: {
    height: 280,
    borderRadius: radius.xl,
    overflow: 'hidden',
    justifyContent: 'space-between',
    padding: spacing.lg,
  },
  heroTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: radius.pill,
  },
  heroBadgeText: { color: '#FFD479', fontSize: 8.5, fontWeight: '800', letterSpacing: 0.7 },
  heroCount: {
    backgroundColor: 'rgba(255,255,255,0.16)',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: radius.pill,
  },
  heroCountText: { color: '#FFFFFF', fontSize: 9.5, fontWeight: '700' },
  heroBottom: {},
  heroEmoji: { fontSize: 22, marginBottom: 4 },
  heroTitle: { color: '#FFFFFF', fontSize: 28, fontWeight: '800', letterSpacing: -0.7 },
  heroSub: { color: 'rgba(255,255,255,0.8)', fontSize: 12.5, fontWeight: '500', marginTop: 4, maxWidth: '90%', lineHeight: 18 },
  heroCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: radius.pill,
    marginTop: 12,
  },
  heroCtaText: { color: '#0B0B12', fontSize: 12, fontWeight: '800' },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 5, marginTop: 12 },
  dot: { height: 6, borderRadius: 3 },
  section: { marginTop: spacing.xxl, paddingHorizontal: spacing.lg },
  moodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  moodCard: { height: 104, borderRadius: radius.lg, padding: 13, justifyContent: 'flex-end' },
  moodIcon: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  moodTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
  moodSub: { color: 'rgba(255,255,255,0.75)', fontSize: 10.5, fontWeight: '500', marginTop: 1 },
  tagWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  footer: { ...typography.caption, textAlign: 'center', marginTop: 16, fontWeight: '500' },
});
