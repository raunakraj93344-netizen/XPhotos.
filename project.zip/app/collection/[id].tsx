import { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Images, Play, Share2, Sparkles } from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { IconButton } from '@/components/IconButton';
import { SectionHeader } from '@/components/SectionHeader';
import { SmartImage } from '@/components/SmartImage';
import { EmptyState } from '@/components/EmptyState';
import { CollectionCard } from '@/components/cards';
import { MasonryGrid } from '@/components/PhotoGrid';
import { useGallery, usePalette } from '@/lib/store';
import { sharePhoto } from '@/lib/utils';
import { radius, spacing, typography } from '@/constants/theme';
import type { Photo } from '@/types';

export default function CollectionScreen() {
  const router = useRouter();
  const palette = usePalette();
  const params = useLocalSearchParams<{ id?: string }>();
  const { curated, getPhoto, photos, favorites } = useGallery();

  const album = curated.find((c) => c.id === params.id);
  const albumPhotos = useMemo(
    () => (album ? album.photoIds.map((id) => photos.find((p) => p.id === id)).filter((p): p is Photo => Boolean(p)) : []),
    [album, photos]
  );

  if (!album) {
    return (
      <Screen>
        <View style={styles.topBar}>
          <IconButton icon={<ArrowLeft size={20} color={palette.text} />} onPress={() => router.back()} />
        </View>
        <EmptyState
          icon={Images}
          title="Collection not found"
          message="This editorial collection is no longer available."
          actionLabel="Discover more"
          onAction={() => router.push('/discover')}
        />
      </Screen>
    );
  }

  const cover = getPhoto(album.photoIds[0]);
  const relatedCollections = curated.filter((c) => c.id !== album.id).slice(0, 5);

  const header = (
    <View style={{ paddingHorizontal: spacing.lg }}>
      <View style={styles.hero}>
        <SmartImage uri={cover?.thumb ?? ''} style={StyleSheet.absoluteFill} radius={radius.xl} />
        <LinearGradient
          colors={['rgba(0,0,0,0.05)', 'rgba(0,0,0,0.4)', 'rgba(0,0,0,0.9)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.heroTop}>
          <View style={styles.heroBadge}>
            <Sparkles size={11} color="#FFD479" />
            <Text style={styles.heroBadgeText}>EDITORIAL COLLECTION</Text>
          </View>
        </View>
        <View style={styles.heroContent}>
          <Text style={styles.heroEmoji}>{album.emoji}</Text>
          <Text style={styles.heroTitle}>{album.title}</Text>
          <Text style={styles.heroSub}>{album.subtitle}</Text>
        </View>
      </View>

      <Text style={[styles.description, { color: palette.textSecondary }]}>{album.description}</Text>

      <View style={styles.metaRow}>
        <View style={[styles.metaPill, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <Images size={13} color={palette.textSecondary} />
          <Text style={[styles.metaPillText, { color: palette.textSecondary }]}>
            {albumPhotos.length} photos
          </Text>
        </View>
        <View style={[styles.metaPill, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <Text style={[styles.metaPillText, { color: palette.textSecondary }]}>#{album.tag}</Text>
        </View>
      </View>

      <View style={styles.actionRow}>
        <Pressable
          onPress={() =>
            albumPhotos[0] && router.push(`/slideshow?start=${albumPhotos[0].id}&collection=${album.id}`)
          }
          style={({ pressed }) => [
            styles.primaryAction,
            { backgroundColor: palette.text, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Play size={15} color={palette.bg} fill={palette.bg} />
          <Text style={[styles.primaryActionText, { color: palette.bg }]}>Play slideshow</Text>
        </Pressable>
        <Pressable
          onPress={() => albumPhotos[0] && sharePhoto(albumPhotos[0])}
          style={({ pressed }) => [
            styles.secondaryAction,
            { backgroundColor: palette.surface, borderColor: palette.border, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Share2 size={16} color={palette.text} />
        </Pressable>
      </View>

      <View style={styles.sectionRow}>
        <Text style={[styles.sectionTitle, { color: palette.text }]}>Inside this collection</Text>
        <Text style={[styles.sectionCount, { color: palette.textMuted }]}>{albumPhotos.length}</Text>
      </View>
    </View>
  );

  return (
    <Screen>
      <View style={styles.topBar}>
        <IconButton
          icon={<ArrowLeft size={20} color={palette.text} />}
          onPress={() => router.back()}
          accessibilityLabel="Go back"
        />
        <Text style={[styles.topTitle, { color: palette.text }]}>Collection</Text>
        <IconButton
          icon={<Share2 size={19} color={palette.text} />}
          onPress={() => albumPhotos[0] && sharePhoto(albumPhotos[0])}
          accessibilityLabel="Share collection"
        />
      </View>

      <MasonryGrid
        photos={albumPhotos}
        favorites={favorites}
        showLabels
        onPressPhoto={(photo) => router.push(`/photo/${photo.id}`)}
        header={header}
        footer={
          <View style={{ marginTop: spacing.xxl }}>
            <View style={{ paddingHorizontal: spacing.lg }}>
              <SectionHeader title="More collections" subtitle="Keep exploring" />
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: 12 }}
            >
              {relatedCollections.map((item) => (
                <CollectionCard
                  key={item.id}
                  title={item.title}
                  subtitle={item.subtitle}
                  uri={getPhoto(item.photoIds[0])?.thumb}
                  gradient={item.gradient}
                  width={190}
                  height={130}
                  onPress={() => router.replace(`/collection/${item.id}`)}
                />
              ))}
            </ScrollView>
          </View>
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: spacing.md,
    paddingBottom: 10,
  },
  topTitle: { ...typography.subheading, flex: 1, textAlign: 'center' },
  hero: { height: 250, borderRadius: radius.xl, overflow: 'hidden', justifyContent: 'space-between', padding: spacing.lg },
  heroTop: { flexDirection: 'row' },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: radius.pill,
  },
  heroBadgeText: { color: '#FFD479', fontSize: 8.5, fontWeight: '800', letterSpacing: 0.7 },
  heroContent: {},
  heroEmoji: { fontSize: 26, marginBottom: 4 },
  heroTitle: { color: '#FFFFFF', fontSize: 30, fontWeight: '800', letterSpacing: -0.8 },
  heroSub: { color: 'rgba(255,255,255,0.8)', fontSize: 12.5, fontWeight: '500', marginTop: 2 },
  description: { ...typography.small, lineHeight: 20, marginTop: spacing.lg },
  metaRow: { flexDirection: 'row', gap: 8, marginTop: spacing.md },
  metaPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    paddingVertical: 7,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  metaPillText: { ...typography.caption, fontWeight: '600' },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: spacing.lg },
  primaryAction: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingVertical: 13,
    borderRadius: radius.pill,
  },
  primaryActionText: { fontSize: 13, fontWeight: '800' },
  secondaryAction: {
    width: 46,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.xl,
    marginBottom: 12,
  },
  sectionTitle: { ...typography.heading },
  sectionCount: { ...typography.caption, fontWeight: '700' },
});
