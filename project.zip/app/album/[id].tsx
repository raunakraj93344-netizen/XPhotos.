import { useMemo, useState } from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ArrowLeft,
  FolderPlus,
  Images,
  MoreHorizontal,
  Pencil,
  Play,
  Plus,
  Share2,
  Trash2,
  X,
} from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { IconButton } from '@/components/IconButton';
import { Sheet } from '@/components/Sheet';
import { EmptyState } from '@/components/EmptyState';
import { SmartImage } from '@/components/SmartImage';
import { MasonryGrid, PhotoGrid } from '@/components/PhotoGrid';
import { useGallery, usePalette } from '@/lib/store';
import { sharePhoto } from '@/lib/utils';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { radius, spacing, typography } from '@/constants/theme';

export default function AlbumDetailScreen() {
  const router = useRouter();
  const palette = usePalette();
  const params = useLocalSearchParams<{ id?: string }>();
  const {
    resolveAlbum,
    photos,
    favorites,
    userAlbums,
    addPhotosToAlbum,
    removePhotosFromAlbum,
    renameAlbum,
    deleteAlbum,
  } = useGallery();

  const album = resolveAlbum(params.id ?? '');
  const [menuOpen, setMenuOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerSelected, setPickerSelected] = useState<string[]>([]);
  const [newName, setNewName] = useState(album?.title ?? '');

  const cover = album?.photos[0];
  const albumIds = useMemo(() => new Set(album?.photoIds ?? []), [album]);
  if (!album) {
    return (
      <Screen>
        <View style={styles.topBar}>
          <IconButton icon={<ArrowLeft size={20} color={palette.text} />} onPress={() => router.back()} />
        </View>
        <EmptyState
          icon={Images}
          title="Album not found"
          message="This album may have been deleted or moved."
          actionLabel="Back to albums"
          onAction={() => router.push('/albums')}
        />
      </Screen>
    );
  }

  const openPicker = () => {
    setPickerSelected(album.photoIds);
    setPickerOpen(true);
  };

  const applyPicker = () => {
    const selectedSet = new Set(pickerSelected);
    const toAdd = pickerSelected.filter((pid) => !albumIds.has(pid));
    const toRemove = album.photoIds.filter((pid) => !selectedSet.has(pid));
    if (toAdd.length > 0) addPhotosToAlbum(album.id, toAdd);
    if (toRemove.length > 0) removePhotosFromAlbum(album.id, toRemove);
    successFeedback();
    setPickerOpen(false);
  };

  const togglePicker = (pid: string) => {
    tapFeedback();
    setPickerSelected((prev) =>
      prev.includes(pid) ? prev.filter((id) => id !== pid) : [...prev, pid]
    );
  };

  const header = (
    <View>
      <View style={{ paddingHorizontal: spacing.lg }}>
        <View style={styles.hero}>
          {cover ? (
            <SmartImage uri={cover.thumb} style={StyleSheet.absoluteFill} radius={radius.xl} />
          ) : (
            <LinearGradient colors={album.gradient} style={StyleSheet.absoluteFill} />
          )}
          <LinearGradient
            colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.45)', 'rgba(0,0,0,0.9)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.heroContent}>
            <View style={styles.heroEmoji}>
              <Text style={{ fontSize: 22 }}>{album.emoji}</Text>
            </View>
            <Text style={styles.heroTitle}>{album.title}</Text>
            <Text style={styles.heroSub}>
              {album.photos.length} {album.photos.length === 1 ? 'photo' : 'photos'} · {album.subtitle}
            </Text>
          </View>
        </View>

        <View style={styles.actionRow}>
          <Pressable
            onPress={() =>
              album.photos[0] && router.push(`/slideshow?start=${album.photos[0].id}&album=${album.id}`)
            }
            style={[styles.actionButton, { backgroundColor: palette.surface, borderColor: palette.border }]}
          >
            <Play size={16} color={palette.text} />
            <Text style={[styles.actionText, { color: palette.text }]}>Slideshow</Text>
          </Pressable>
          <Pressable
            onPress={() => album.photos[0] && sharePhoto(album.photos[0])}
            style={[styles.actionButton, { backgroundColor: palette.surface, borderColor: palette.border }]}
          >
            <Share2 size={16} color={palette.text} />
            <Text style={[styles.actionText, { color: palette.text }]}>Share</Text>
          </Pressable>
          {album.isUser ? (
            <Pressable
              onPress={openPicker}
              style={[styles.actionButton, { backgroundColor: palette.text, borderColor: palette.text }]}
            >
              <Plus size={16} color={palette.bg} />
              <Text style={[styles.actionText, { color: palette.bg }]}>Add photos</Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={() => router.push('/')}
              style={[styles.actionButton, { backgroundColor: palette.surface, borderColor: palette.border }]}
            >
              <Images size={16} color={palette.text} />
              <Text style={[styles.actionText, { color: palette.text }]}>Library</Text>
            </Pressable>
          )}
        </View>

        <View style={styles.sectionRow}>
          <Text style={[styles.sectionTitle, { color: palette.text }]}>Photos</Text>
          <Text style={[styles.sectionCount, { color: palette.textMuted }]}>
            {album.photos.length} items
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <Screen>
      <View style={styles.topBar}>
        <IconButton
          icon={<ArrowLeft size={20} color={palette.text} />}
          onPress={() => router.back()}
          accessibilityLabel="Go back"
        />
        <Text style={[styles.topTitle, { color: palette.text }]} numberOfLines={1}>
          {album.emoji} {album.title}
        </Text>
        <IconButton
          icon={<MoreHorizontal size={20} color={palette.text} />}
          onPress={() => setMenuOpen(true)}
          accessibilityLabel="Album options"
        />
      </View>

      <MasonryGrid
        photos={album.photos}
        favorites={favorites}
        onPressPhoto={(photo) => router.push(`/photo/${photo.id}`)}
        header={header}
        showLabels
        empty={
          <EmptyState
            icon={FolderPlus}
            title="This album is empty"
            message={
              album.isUser
                ? 'Pick photos from your library to start filling this album.'
                : 'Nothing here yet — favorite photos or add captures to fill this up.'
            }
            actionLabel={album.isUser ? 'Add photos' : 'Browse library'}
            onAction={() => (album.isUser ? openPicker() : router.push('/'))}
          />
        }
        footer={
          <Text style={[styles.footerText, { color: palette.textMuted }]}>
            {album.isSmart ? 'Smart album · updates automatically' : 'Curated by you'}
          </Text>
        }
      />

      <Sheet visible={menuOpen} onClose={() => setMenuOpen(false)} title="Album options">
        {album.isUser ? (
          <>
            <Pressable
              onPress={() => {
                setMenuOpen(false);
                setTimeout(openPicker, 180);
              }}
              style={styles.menuRow}
            >
              <FolderPlus size={17} color={palette.textSecondary} />
              <Text style={[styles.menuText, { color: palette.text }]}>Add or remove photos</Text>
            </Pressable>
            <Pressable
              onPress={() => {
                setMenuOpen(false);
                setNewName(album.title);
                setTimeout(() => setRenameOpen(true), 180);
              }}
              style={styles.menuRow}
            >
              <Pencil size={17} color={palette.textSecondary} />
              <Text style={[styles.menuText, { color: palette.text }]}>Rename album</Text>
            </Pressable>
          </>
        ) : null}
        <Pressable
          onPress={() => {
            setMenuOpen(false);
            if (album.photos[0]) router.push(`/slideshow?start=${album.photos[0].id}&album=${album.id}`);
          }}
          style={styles.menuRow}
        >
          <Play size={17} color={palette.textSecondary} />
          <Text style={[styles.menuText, { color: palette.text }]}>Play slideshow</Text>
        </Pressable>
        {album.isUser ? (
          <Pressable
            onPress={() => {
              setMenuOpen(false);
              setTimeout(() => setDeleteOpen(true), 180);
            }}
            style={styles.menuRow}
          >
            <Trash2 size={17} color={palette.danger} />
            <Text style={[styles.menuText, { color: palette.danger }]}>Delete album</Text>
          </Pressable>
        ) : null}
      </Sheet>

      <Sheet visible={renameOpen} onClose={() => setRenameOpen(false)} title="Rename album">
        <TextInput
          value={newName}
          onChangeText={setNewName}
          placeholder="Album name"
          placeholderTextColor={palette.textMuted}
          style={[
            styles.input,
            { backgroundColor: palette.surfaceAlt, borderColor: palette.border, color: palette.text },
          ]}
          autoFocus
          maxLength={40}
        />
        <Pressable
          onPress={() => {
            renameAlbum(album.id, newName);
            setRenameOpen(false);
          }}
          style={[styles.primaryButton, { backgroundColor: palette.text }]}
        >
          <Text style={[styles.primaryText, { color: palette.bg }]}>Save changes</Text>
        </Pressable>
      </Sheet>

      <Sheet visible={deleteOpen} onClose={() => setDeleteOpen(false)} title="Delete album?">
        <Text style={[styles.sheetText, { color: palette.textMuted }]}>
          “{album.title}” will be deleted. The photos inside stay safe in your library.
        </Text>
        <View style={styles.sheetActions}>
          <Pressable
            onPress={() => setDeleteOpen(false)}
            style={[styles.secondaryButton, { borderColor: palette.border }]}
          >
            <Text style={[styles.secondaryText, { color: palette.text }]}>Cancel</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              deleteAlbum(album.id);
              setDeleteOpen(false);
              router.back();
            }}
            style={[styles.primaryButton, { backgroundColor: palette.danger }]}
          >
            <Text style={[styles.primaryText, { color: '#FFFFFF' }]}>Delete</Text>
          </Pressable>
        </View>
      </Sheet>

      <Modal visible={pickerOpen} animationType="slide" onRequestClose={() => setPickerOpen(false)}>
        <Screen>
          <View style={styles.pickerBar}>
            <IconButton
              icon={<X size={20} color={palette.text} />}
              onPress={() => setPickerOpen(false)}
              accessibilityLabel="Close picker"
            />
            <View style={{ flex: 1 }}>
              <Text style={[styles.pickerTitle, { color: palette.text }]}>Add photos</Text>
              <Text style={[styles.pickerSub, { color: palette.textMuted }]}>
                {pickerSelected.length} selected · {album.title}
              </Text>
            </View>
            <Pressable
              onPress={applyPicker}
              style={({ pressed }) => [styles.doneButton, { backgroundColor: palette.text, opacity: pressed ? 0.8 : 1 }]}
            >
              <Text style={[styles.doneText, { color: palette.bg }]}>Done</Text>
            </Pressable>
          </View>
          <PhotoGrid
            photos={photos}
            favorites={favorites}
            selectionMode
            selectedIds={pickerSelected}
            onPressPhoto={(photo) => togglePicker(photo.id)}
            header={
              <Text style={[styles.pickerHint, { color: palette.textMuted }]}>
                Tap to add or remove. Photos already in this album are pre-selected.
              </Text>
            }
            extraBottom={0}
          />
        </Screen>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: spacing.md,
    paddingBottom: 10,
  },
  topTitle: { ...typography.subheading, flex: 1, textAlign: 'center' },
  hero: {
    height: 220,
    borderRadius: radius.xl,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  heroContent: { padding: spacing.lg },
  heroEmoji: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.16)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  heroTitle: { color: '#FFFFFF', fontSize: 28, fontWeight: '800', letterSpacing: -0.7 },
  heroSub: { color: 'rgba(255,255,255,0.78)', fontSize: 12, fontWeight: '500', marginTop: 3 },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: spacing.md },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 11,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  actionText: { fontSize: 11.5, fontWeight: '700' },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.xl,
    marginBottom: 12,
  },
  sectionTitle: { ...typography.heading },
  sectionCount: { ...typography.caption, fontWeight: '600' },
  footerText: { ...typography.caption, textAlign: 'center', marginTop: 20, fontWeight: '500' },
  menuRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14 },
  menuText: { ...typography.body, fontWeight: '600' },
  input: {
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    height: 48,
    ...typography.body,
    marginBottom: spacing.lg,
  },
  primaryButton: { alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: radius.lg },
  primaryText: { ...typography.body, fontWeight: '800' },
  secondaryButton: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth },
  secondaryText: { ...typography.body, fontWeight: '700' },
  sheetText: { ...typography.small, lineHeight: 20 },
  sheetActions: { flexDirection: 'row', gap: 10, marginTop: spacing.lg },
  pickerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: spacing.md,
    paddingBottom: 12,
  },
  pickerTitle: { ...typography.subheading, textAlign: 'center' },
  pickerSub: { ...typography.caption, textAlign: 'center', marginTop: 1, fontWeight: '500' },
  doneButton: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: radius.pill },
  doneText: { fontSize: 12.5, fontWeight: '800' },
  pickerHint: { ...typography.caption, paddingHorizontal: 4, paddingBottom: 10, fontWeight: '500' },
});
