import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Compass } from 'lucide-react-native';
import { Screen } from '@/components/Screen';
import { Brand } from '@/components/Brand';
import { usePalette } from '@/lib/store';
import { radius, spacing, typography } from '@/constants/theme';

export default function NotFoundScreen() {
  const palette = usePalette();
  const router = useRouter();
  return (
    <Screen>
      <View style={styles.top}>
        <Brand />
      </View>
      <View style={styles.center}>
        <View style={[styles.icon, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }]}>
          <Compass size={30} color={palette.textMuted} />
        </View>
        <Text style={[styles.code, { color: palette.textMuted }]}>404</Text>
        <Text style={[styles.title, { color: palette.text }]}>This frame is missing</Text>
        <Text style={[styles.message, { color: palette.textMuted }]}>
          The page you are looking for does not exist or was moved.
        </Text>
        <Pressable
          onPress={() => router.replace('/(tabs)')}
          style={({ pressed }) => [styles.button, { backgroundColor: palette.text, opacity: pressed ? 0.8 : 1 }]}
        >
          <Text style={[styles.buttonText, { color: palette.bg }]}>Back to library</Text>
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { paddingHorizontal: spacing.lg, paddingTop: spacing.sm },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
  icon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.md,
  },
  code: { ...typography.caption, letterSpacing: 3, fontWeight: '800' },
  title: { ...typography.title, marginTop: 6, textAlign: 'center' },
  message: { ...typography.small, textAlign: 'center', marginTop: 8, maxWidth: 280, lineHeight: 20 },
  button: { marginTop: spacing.xl, paddingHorizontal: 26, paddingVertical: 13, borderRadius: radius.pill },
  buttonText: { ...typography.body, fontWeight: '800' },
});
