import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { GalleryProvider, useGallery } from '@/lib/store';

function ThemedStack() {
  const { palette } = useGallery();
  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: palette.bg },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="photo/[id]" options={{ animation: 'fade' }} />
        <Stack.Screen name="album/[id]" />
        <Stack.Screen name="collection/[id]" />
        <Stack.Screen name="slideshow" options={{ animation: 'fade', presentation: 'fullScreenModal' }} />
        <Stack.Screen name="camera" options={{ animation: 'slide_from_bottom', presentation: 'fullScreenModal' }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style={palette.isDark ? 'light' : 'dark'} />
    </>
  );
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <GalleryProvider>
          <ThemedStack />
        </GalleryProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
