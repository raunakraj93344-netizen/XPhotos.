import { StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Aperture } from 'lucide-react-native';
import { gradients } from '@/constants/theme';
import { usePalette } from '@/lib/store';

type Props = {
  size?: 'md' | 'lg';
  showTagline?: boolean;
};

export function Brand({ size = 'md', showTagline = false }: Props) {
  const palette = usePalette();
  const mark = size === 'lg' ? 44 : 34;
  return (
    <View style={styles.row}>
      <LinearGradient
        colors={gradients.violet}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.mark, { width: mark, height: mark, borderRadius: mark * 0.32 }]}
      >
        <Aperture size={mark * 0.58} color="#FFFFFF" strokeWidth={2.2} />
      </LinearGradient>
      <View>
        <Text style={[styles.wordmark, { color: palette.text, fontSize: size === 'lg' ? 26 : 21 }]}>
          XPhotos
        </Text>
        {showTagline ? (
          <Text style={[styles.tagline, { color: palette.textMuted }]}>Every frame, beautifully organized</Text>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  mark: { alignItems: 'center', justifyContent: 'center' },
  wordmark: { fontWeight: '800', letterSpacing: -0.6 },
  tagline: { fontSize: 11.5, fontWeight: '500', marginTop: 1 },
});
