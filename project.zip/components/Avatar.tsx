import { StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradients } from '@/constants/theme';
import { initials } from '@/lib/utils';
import { usePalette } from '@/lib/store';

type Props = {
  name: string;
  size?: number;
  gradientKey?: keyof typeof gradients;
};

export function Avatar({ name, size = 40, gradientKey = 'violet' }: Props) {
  const palette = usePalette();
  return (
    <LinearGradient
      colors={gradients[gradientKey]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[
        styles.base,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: palette.border,
        },
      ]}
    >
      <Text style={[styles.text, { fontSize: size * 0.36 }]}>{initials(name)}</Text>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  base: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
  },
  text: { color: '#FFFFFF', fontWeight: '800', letterSpacing: 0.5 },
});
