import { Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { usePalette } from '@/lib/store';
import { radius, typography } from '@/constants/theme';

type Option = { key: string; label: string; count?: number };

type Props = {
  options: Option[];
  value: string;
  onChange: (key: string) => void;
  style?: StyleProp<ViewStyle>;
};

export function Segmented({ options, value, onChange, style }: Props) {
  const palette = usePalette();
  return (
    <View style={[styles.track, { backgroundColor: palette.surfaceAlt, borderColor: palette.border }, style]}>
      {options.map((option) => {
        const active = option.key === value;
        return (
          <Pressable
            key={option.key}
            onPress={() => onChange(option.key)}
            style={[styles.item, active && { backgroundColor: palette.surface, borderColor: palette.border }]}
          >
            <Text
              style={[
                styles.label,
                { color: active ? palette.text : palette.textMuted },
                active && { fontWeight: '700' },
              ]}
            >
              {option.label}
              {option.count !== undefined ? ` ${option.count}` : ''}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    flexDirection: 'row',
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 4,
    gap: 2,
  },
  item: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'transparent',
  },
  label: { ...typography.small, fontWeight: '600' },
});
