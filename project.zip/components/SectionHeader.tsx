import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ChevronRight } from 'lucide-react-native';
import { usePalette } from '@/lib/store';
import { typography } from '@/constants/theme';

type Props = {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  right?: React.ReactNode;
};

export function SectionHeader({ title, subtitle, actionLabel, onAction, right }: Props) {
  const palette = usePalette();
  return (
    <View style={styles.row}>
      <View style={styles.left}>
        <Text style={[styles.title, { color: palette.text }]}>{title}</Text>
        {subtitle ? (
          <Text style={[styles.subtitle, { color: palette.textMuted }]}>{subtitle}</Text>
        ) : null}
      </View>
      {right}
      {actionLabel && onAction ? (
        <Pressable onPress={onAction} style={styles.action} hitSlop={8}>
          <Text style={[styles.actionText, { color: palette.primary }]}>{actionLabel}</Text>
          <ChevronRight size={15} color={palette.primary} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 8,
  },
  left: { flex: 1 },
  title: { ...typography.heading },
  subtitle: { ...typography.small, marginTop: 2 },
  action: { flexDirection: 'row', alignItems: 'center', gap: 1, paddingBottom: 2 },
  actionText: { ...typography.small, fontWeight: '700' },
});
