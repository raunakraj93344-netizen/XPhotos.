import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronRight, Crown, Image as ImageIcon, Sparkles } from 'lucide-react-native';
import { gradients, radius, typography, type Gradient, type GradientKey } from '@/constants/theme';
import { usePalette } from '@/lib/store';
import { SmartImage } from './SmartImage';

export function CollectionCard({
  title,
  subtitle,
  uri,
  gradient = 'violet',
  width,
  height,
  onPress,
}: {
  title: string;
  subtitle: string;
  uri?: string;
  gradient?: GradientKey;
  width: number;
  height: number;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.collection,
        { width, height, opacity: pressed ? 0.88 : 1, borderColor: 'rgba(255,255,255,0.08)' },
      ]}
    >
      {uri ? (
        <SmartImage uri={uri} style={StyleSheet.absoluteFill} radius={radius.xl} />
      ) : (
        <LinearGradient colors={gradients[gradient]} style={StyleSheet.absoluteFill} />
      )}
      <LinearGradient
        colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.82)']}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.collectionText}>
        <Text style={styles.collectionTitle} numberOfLines={1}>
          {title}
        </Text>
        <Text style={styles.collectionSub} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
    </Pressable>
  );
}

export function StoryRing({
  title,
  uri,
  gradient = 'violet',
  onPress,
  seen = false,
}: {
  title: string;
  uri: string;
  gradient?: GradientKey;
  onPress: () => void;
  seen?: boolean;
}) {
  const palette = usePalette();
  return (
    <Pressable onPress={onPress} style={styles.storyRoot}>
      <LinearGradient
        colors={seen ? [palette.border, palette.border] : gradients[gradient]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.storyRing}
      >
        <View style={[styles.storyInner, { backgroundColor: palette.bg }]}>
          <SmartImage uri={uri} style={styles.storyImage} radius={30} />
        </View>
      </LinearGradient>
      <Text style={[styles.storyLabel, { color: palette.textSecondary }]} numberOfLines={1}>
        {title}
      </Text>
    </Pressable>
  );
}

export function AlbumCard({
  title,
  count,
  uri,
  emoji,
  gradient = 'violet',
  width,
  height = 132,
  onPress,
}: {
  title: string;
  count: number;
  uri?: string;
  emoji: string;
  gradient?: GradientKey;
  width: number;
  height?: number;
  onPress: () => void;
}) {
  const palette = usePalette();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.album,
        {
          width,
          height,
          borderColor: palette.border,
          backgroundColor: palette.surface,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
    >
      {uri ? (
        <SmartImage uri={uri} style={StyleSheet.absoluteFill} radius={radius.lg} />
      ) : (
        <LinearGradient colors={gradients[gradient]} style={StyleSheet.absoluteFill} />
      )}
      <LinearGradient colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.85)']} style={StyleSheet.absoluteFill} />
      <View style={styles.albumEmoji}>
        <Text style={{ fontSize: 14 }}>{emoji}</Text>
      </View>
      <View style={styles.albumText}>
        <Text style={styles.albumTitle} numberOfLines={1}>
          {title}
        </Text>
        <Text style={styles.albumCount}>{count} photos</Text>
      </View>
    </Pressable>
  );
}

export function CategoryCard({
  title,
  count,
  uri,
  gradient = 'ocean',
  width,
  height = 104,
  onPress,
}: {
  title: string;
  count: number;
  uri?: string;
  gradient?: GradientKey;
  width: number;
  height?: number;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.category,
        { width, height, opacity: pressed ? 0.85 : 1 },
      ]}
    >
      {uri ? (
        <SmartImage uri={uri} style={StyleSheet.absoluteFill} radius={radius.lg} />
      ) : (
        <LinearGradient colors={gradients[gradient]} style={StyleSheet.absoluteFill} />
      )}
      <LinearGradient colors={['rgba(0,0,0,0.1)', 'rgba(0,0,0,0.78)']} style={StyleSheet.absoluteFill} />
      <View style={styles.categoryText}>
        <Text style={styles.categoryTitle}>{title}</Text>
        <Text style={styles.categoryCount}>{count} photos</Text>
      </View>
      <View style={styles.categoryArrow}>
        <ChevronRight size={14} color="#FFFFFF" />
      </View>
    </Pressable>
  );
}

export function ProBanner({ onPress }: { onPress: () => void }) {
  const palette = usePalette();
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1 })}>
      <LinearGradient
        colors={['#2B1B63', '#5C2A8A', '#8E3B72']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.pro, { borderColor: palette.border }]}
      >
        <View style={styles.proIcon}>
          <Crown size={20} color="#FFD479" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.proTitle}>XPhotos Pro</Text>
          <Text style={styles.proSub}>Unlimited cloud backup, AI search and 8K exports.</Text>
        </View>
        <View style={styles.proCta}>
          <Text style={styles.proCtaText}>Upgrade</Text>
          <Sparkles size={13} color="#2B1B63" />
        </View>
      </LinearGradient>
    </Pressable>
  );
}

export function MemoryCard({
  uri,
  count,
  onPress,
  onReplay,
}: {
  uri: string;
  count: number;
  onPress: () => void;
  onReplay: () => void;
}) {
  return (
    <View style={styles.memoryWrap}>
      <Pressable onPress={onPress} style={({ pressed }) => [styles.memory, { opacity: pressed ? 0.92 : 1 }]}>
        <SmartImage uri={uri} style={StyleSheet.absoluteFill} radius={radius.xl} />
        <LinearGradient
          colors={['rgba(0,0,0,0.15)', 'rgba(0,0,0,0.86)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.memoryBadge}>
          <Sparkles size={12} color="#FFD479" />
          <Text style={styles.memoryBadgeText}>MEMORIES</Text>
        </View>
        <View style={styles.memoryBottom}>
          <Text style={styles.memoryTitle}>On this day</Text>
          <Text style={styles.memorySub}>{count} photos from your journey</Text>
        </View>
      </Pressable>
      <Pressable
        onPress={onReplay}
        style={({ pressed }) => [styles.memoryButton, { opacity: pressed ? 0.8 : 1 }]}
      >
        <Text style={styles.memoryButtonText}>Replay</Text>
      </Pressable>
    </View>
  );
}

export function PhotoOfDayCard({
  uri,
  title,
  photographer,
  onPress,
}: {
  uri: string;
  title: string;
  photographer: string;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.pod, { opacity: pressed ? 0.92 : 1 }]}>
      <SmartImage uri={uri} style={StyleSheet.absoluteFill} radius={radius.xl} />
      <LinearGradient
        colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.05)', 'rgba(0,0,0,0.88)']}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.podTop}>
        <View style={styles.podBadge}>
          <ImageIcon size={12} color="#FFFFFF" />
          <Text style={styles.podBadgeText}>PHOTO OF THE DAY</Text>
        </View>
      </View>
      <View style={styles.podBottom}>
        <Text style={styles.podTitle}>{title}</Text>
        <Text style={styles.podSub}>by {photographer}</Text>
      </View>
    </Pressable>
  );
}

export function GradientStat({ colors }: { colors: Gradient }) {
  return <LinearGradient colors={colors} style={styles.gradientStat} />;
}

const styles = StyleSheet.create({
  collection: {
    borderRadius: radius.xl,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    justifyContent: 'flex-end',
  },
  collectionText: { padding: 16 },
  collectionTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: '800', letterSpacing: -0.3 },
  collectionSub: { color: 'rgba(255,255,255,0.78)', fontSize: 12, fontWeight: '500', marginTop: 2 },

  storyRoot: { alignItems: 'center', width: 76, gap: 6 },
  storyRing: { width: 70, height: 70, borderRadius: 35, padding: 2.5 },
  storyInner: { flex: 1, borderRadius: 32, padding: 2 },
  storyImage: { flex: 1 },
  storyLabel: { fontSize: 11, fontWeight: '600', maxWidth: 72 },

  album: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    justifyContent: 'flex-end',
  },
  albumEmoji: {
    position: 'absolute',
    top: 10,
    left: 10,
    width: 28,
    height: 28,
    borderRadius: 9,
    backgroundColor: 'rgba(0,0,0,0.42)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  albumText: { padding: 12 },
  albumTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  albumCount: { color: 'rgba(255,255,255,0.72)', fontSize: 11, fontWeight: '500', marginTop: 1 },

  category: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  categoryText: { padding: 12 },
  categoryTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  categoryCount: { color: 'rgba(255,255,255,0.72)', fontSize: 10.5, fontWeight: '500', marginTop: 1 },
  categoryArrow: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  pro: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
  },
  proIcon: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proTitle: { color: '#FFFFFF', fontSize: 15, fontWeight: '800' },
  proSub: { color: 'rgba(255,255,255,0.7)', fontSize: 11.5, fontWeight: '500', marginTop: 2 },
  proCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FFD479',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: radius.pill,
  },
  proCtaText: { color: '#2B1B63', fontSize: 12, fontWeight: '800' },

  memoryWrap: { position: 'relative' },
  memory: {
    height: 180,
    borderRadius: radius.xl,
    overflow: 'hidden',
    justifyContent: 'space-between',
    padding: 16,
  },
  memoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: radius.pill,
  },
  memoryBadgeText: { color: '#FFD479', fontSize: 9.5, fontWeight: '800', letterSpacing: 0.8 },
  memoryBottom: { paddingRight: 96 },
  memoryTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  memorySub: { color: 'rgba(255,255,255,0.78)', fontSize: 12, fontWeight: '500', marginTop: 2 },
  memoryButton: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    backgroundColor: 'rgba(255,255,255,0.95)',
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: radius.pill,
  },
  memoryButtonText: { color: '#0B0B12', fontSize: 12, fontWeight: '800' },

  pod: { height: 210, borderRadius: radius.xl, overflow: 'hidden', justifyContent: 'space-between', padding: 16 },
  podTop: { flexDirection: 'row' },
  podBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.42)',
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: radius.pill,
  },
  podBadgeText: { color: '#FFFFFF', fontSize: 9, fontWeight: '800', letterSpacing: 0.8 },
  podBottom: {},
  podTitle: { color: '#FFFFFF', fontSize: 22, fontWeight: '800', letterSpacing: -0.4 },
  podSub: { color: 'rgba(255,255,255,0.78)', fontSize: 12, fontWeight: '500', marginTop: 2 },

  gradientStat: { flex: 1, borderRadius: radius.lg },
});
