import { SafeAreaView } from 'react-native-safe-area-context';
import { StyleSheet, type StyleProp, type ViewStyle } from 'react-native';
import type { ReactNode } from 'react';
import { usePalette } from '@/lib/store';

type Props = {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  edges?: Array<'top' | 'bottom' | 'left' | 'right'>;
};

export function Screen({ children, style, edges = ['top', 'left', 'right'] }: Props) {
  const palette = usePalette();
  return (
    <SafeAreaView edges={edges} style={[styles.root, { backgroundColor: palette.bg }, style]}>
      {children}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
});
