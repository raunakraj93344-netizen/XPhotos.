import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { usePalette } from '@/lib/store';
import { radius, typography } from '@/constants/theme';

type Props = {
  icon: LucideIcon;
  label: string;
  value: string;
  tint?: string;
  onPress?: () => void;
};

export function StatTile({ icon: Icon, label, value, tint, onPress }: Props) {
  const palette = usePalette();
  const color = tint ?? palette.primary;
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.tile,
        {
          backgroundColor: palette.surface,
          borderColor: palette.border,
          opacity: pressed ? 0.8 : 1,
        },
      ]}
    >
      <View style={[styles.iconWrap, { backgroundColor: `${color}1F` }]}>
        <Icon size={16} color={color} />
      </View>
      <Text style={[styles.value, { color: palette.text }]}>{value}</Text>
      <Text style={[styles.label, { color: palette.textMuted }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    flex: 1,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 12,
    gap: 2,
  },
  iconWrap: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  value: { ...typography.subheading, fontSize: 17 },
  label: { ...typography.caption, textTransform: 'uppercase' },
});
