import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { ReactNode } from 'react';
import { usePalette } from '@/lib/store';
import { radius, spacing, typography } from '@/constants/theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  scroll?: boolean;
  tone?: 'default' | 'dark';
};

export function Sheet({ visible, onClose, title, children, scroll = false, tone = 'default' }: Props) {
  const palette = usePalette();
  const insets = useSafeAreaInsets();
  const dark = tone === 'dark';
  const surfaceColor = dark ? '#0E0E15' : palette.bgElevated;
  const borderColor = dark ? '#262633' : palette.border;
  const titleColor = dark ? '#F6F6FA' : palette.text;

  const content = scroll ? (
    <ScrollView
      style={{ maxHeight: 520 }}
      contentContainerStyle={{ paddingBottom: spacing.sm }}
      showsVerticalScrollIndicator={false}
    >
      {children}
    </ScrollView>
  ) : (
    children
  );

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={styles.root}>
        <Pressable style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.6)' }]} onPress={onClose} />
        <View
          style={[
            styles.sheet,
            {
              backgroundColor: surfaceColor,
              borderColor,
              paddingBottom: Math.max(insets.bottom, spacing.lg),
            },
          ]}
        >
          <View style={[styles.handle, { backgroundColor: dark ? '#343444' : palette.borderStrong }]} />
          {title ? <Text style={[styles.title, { color: titleColor }]}>{title}</Text> : null}
          {content}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  sheet: {
    borderTopLeftRadius: radius.xxl,
    borderTopRightRadius: radius.xxl,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: spacing.lg,
  },
  title: { ...typography.heading, marginBottom: spacing.md },
});
