import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import type { LucideIcon } from 'lucide-react-native';
import { ChevronRight } from 'lucide-react-native';
import { usePalette } from '@/lib/store';
import { radius, typography } from '@/constants/theme';

type Props = {
  icon?: LucideIcon;
  title: string;
  subtitle?: string;
  value?: string;
  onPress?: () => void;
  toggle?: boolean;
  onToggle?: (next: boolean) => void;
  danger?: boolean;
  last?: boolean;
};

export function SettingRow({
  icon: Icon,
  title,
  subtitle,
  value,
  onPress,
  toggle,
  onToggle,
  danger,
  last,
}: Props) {
  const palette = usePalette();
  const tint = danger ? palette.danger : palette.text;

  const body = (
    <View style={[styles.row, !last && { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: palette.border }]}>
      {Icon ? (
        <View style={[styles.iconWrap, { backgroundColor: palette.surfaceAlt }]}>
          <Icon size={17} color={danger ? palette.danger : palette.textSecondary} />
        </View>
      ) : null}
      <View style={styles.textWrap}>
        <Text style={[styles.title, { color: tint }]}>{title}</Text>
        {subtitle ? (
          <Text style={[styles.subtitle, { color: palette.textMuted }]}>{subtitle}</Text>
        ) : null}
      </View>
      {toggle && onToggle ? (
        <Switch
          value={value === 'on'}
          onValueChange={onToggle}
          trackColor={{ false: palette.borderStrong, true: palette.primary }}
          thumbColor="#FFFFFF"
        />
      ) : (
        <View style={styles.right}>
          {value ? <Text style={[styles.value, { color: palette.textMuted }]}>{value}</Text> : null}
          {onPress ? <ChevronRight size={17} color={palette.textMuted} /> : null}
        </View>
      )}
    </View>
  );

  if (!onPress) return body;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.65 : 1 })}>
      {body}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
  },
  iconWrap: {
    width: 34,
    height: 34,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: { flex: 1 },
  title: { ...typography.body, fontWeight: '600' },
  subtitle: { ...typography.caption, marginTop: 2, fontWeight: '500' },
  right: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  value: { ...typography.small },
});
