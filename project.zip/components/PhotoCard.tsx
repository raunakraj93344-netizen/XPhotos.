import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Check, Heart } from 'lucide-react-native';
import { usePalette } from '@/lib/store';
import { radius } from '@/constants/theme';
import type { Photo } from '@/types';
import { SmartImage } from './SmartImage';

type Props = {
  photo: Photo;
  width: number;
  height: number;
  onPress: () => void;
  onLongPress?: () => void;
  selected?: boolean;
  selectionMode?: boolean;
  favorite?: boolean;
  showLabel?: boolean;
  radiusValue?: number;
};

export function PhotoCard({
  photo,
  width,
  height,
  onPress,
  onLongPress,
  selected = false,
  selectionMode = false,
  favorite = false,
  showLabel = false,
  radiusValue = radius.lg,
}: Props) {
  const palette = usePalette();
  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      delayLongPress={260}
      style={({ pressed }) => [
        styles.card,
        { width, height, borderRadius: radiusValue, borderColor: palette.border },
        { opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <SmartImage uri={photo.thumb} style={StyleSheet.absoluteFill} radius={radiusValue} />

      {showLabel ? (
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.78)']}
          style={styles.labelGradient}
        >
          <Text style={styles.labelTitle} numberOfLines={1}>
            {photo.title}
          </Text>
          <Text style={styles.labelSub} numberOfLines={1}>
            {photo.location}
          </Text>
        </LinearGradient>
      ) : null}

      {favorite && !selectionMode ? (
        <View style={styles.heart}>
          <Heart size={13} color="#FF6F91" fill="#FF6F91" />
        </View>
      ) : null}

      {selectionMode ? (
        <View
          style={[
            styles.check,
            {
              backgroundColor: selected ? palette.primary : 'rgba(0,0,0,0.35)',
              borderColor: selected ? palette.primary : 'rgba(255,255,255,0.85)',
            },
          ]}
        >
          {selected ? <Check size={14} color="#FFFFFF" strokeWidth={3} /> : null}
        </View>
      ) : null}

      {selected ? (
        <View style={[styles.selectedBorder, { borderColor: palette.primary }]} pointerEvents="none" />
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    backgroundColor: '#111',
  },
  labelGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 10,
    paddingTop: 26,
    paddingBottom: 9,
  },
  labelTitle: { color: '#FFFFFF', fontSize: 12.5, fontWeight: '700' },
  labelSub: { color: 'rgba(255,255,255,0.72)', fontSize: 10.5, fontWeight: '500', marginTop: 1 },
  heart: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(0,0,0,0.45)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  check: {
    position: 'absolute',
    top: 8,
    left: 8,
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedBorder: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 3,
    borderRadius: radius.lg,
  },
});
