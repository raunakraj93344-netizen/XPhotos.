import { Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import type { ReactNode } from 'react';
import { usePalette } from '@/lib/store';
import { radius, typography } from '@/constants/theme';

type Props = {
  label: string;
  active?: boolean;
  onPress?: () => void;
  icon?: ReactNode;
  style?: StyleProp<ViewStyle>;
  size?: 'sm' | 'md';
};

export function Chip({ label, active = false, onPress, icon, style, size = 'md' }: Props) {
  const palette = usePalette();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.base,
        size === 'sm' && styles.small,
        {
          backgroundColor: active ? palette.text : palette.surfaceAlt,
          borderColor: active ? palette.text : palette.border,
          opacity: pressed ? 0.75 : 1,
        },
        style,
      ]}
    >
      {icon}
      <Text
        style={[
          styles.label,
          { color: active ? palette.bg : palette.textSecondary },
          size === 'sm' && { fontSize: 12 },
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  small: { paddingHorizontal: 11, paddingVertical: 7 },
  label: { ...typography.small, fontWeight: '600' },
});
