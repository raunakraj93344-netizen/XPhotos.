import { useState } from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { Image as ExpoImage } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { ImageOff } from 'lucide-react-native';
import { gradients } from '@/constants/theme';
import { usePalette } from '@/lib/store';

type Props = {
  uri: string;
  style?: StyleProp<ViewStyle>;
  radius?: number;
  contentFit?: 'cover' | 'contain';
  transparent?: boolean;
};

export function SmartImage({ uri, style, radius = 0, contentFit = 'cover', transparent = false }: Props) {
  const palette = usePalette();
  const [failed, setFailed] = useState(false);

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: transparent ? 'transparent' : palette.surfaceAlt, borderRadius: radius },
        style,
      ]}
    >
      {failed ? (
        <LinearGradient
          colors={[gradients.violet[0], gradients.candy[1]]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[StyleSheet.absoluteFill, styles.center, { borderRadius: radius }]}
        >
          <ImageOff size={26} color="rgba(255,255,255,0.85)" />
        </LinearGradient>
      ) : (
        <ExpoImage
          source={{ uri }}
          style={[StyleSheet.absoluteFill, { borderRadius: radius }]}
          contentFit={contentFit}
          transition={280}
          cachePolicy="memory-disk"
          onError={() => setFailed(true)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { overflow: 'hidden' },
  center: { alignItems: 'center', justifyContent: 'center' },
});
