import { Pressable, StyleSheet, type StyleProp, type ViewStyle } from 'react-native';
import type { ReactNode } from 'react';
import { usePalette } from '@/lib/store';
import { tapFeedback } from '@/lib/haptics';

type Props = {
  icon: ReactNode;
  onPress?: () => void;
  size?: number;
  variant?: 'soft' | 'solid' | 'ghost';
  style?: StyleProp<ViewStyle>;
  accessibilityLabel?: string;
  disabled?: boolean;
};

export function IconButton({
  icon,
  onPress,
  size = 42,
  variant = 'soft',
  style,
  accessibilityLabel,
  disabled,
}: Props) {
  const palette = usePalette();
  const background =
    variant === 'solid' ? palette.text : variant === 'ghost' ? 'transparent' : palette.surfaceAlt;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      disabled={disabled}
      onPress={() => {
        tapFeedback();
        onPress?.();
      }}
      style={({ pressed }) => [
        styles.base,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: background,
          borderColor: variant === 'ghost' ? 'transparent' : palette.border,
          opacity: disabled ? 0.4 : pressed ? 0.7 : 1,
        },
        style,
      ]}
    >
      {icon}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
  },
});
