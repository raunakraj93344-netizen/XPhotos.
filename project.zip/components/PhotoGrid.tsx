import { FlatList, ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';
import { useMemo, type ReactNode } from 'react';
import type { Photo } from '@/types';
import { PhotoCard } from './PhotoCard';
import { useGallery } from '@/lib/store';
import { spacing } from '@/constants/theme';

type CommonProps = {
  photos: Photo[];
  onPressPhoto: (photo: Photo, index: number) => void;
  onLongPressPhoto?: (photo: Photo) => void;
  selectionMode?: boolean;
  selectedIds?: string[];
  favorites?: string[];
  showLabels?: boolean;
  header?: ReactNode;
  footer?: ReactNode;
  padding?: number;
  gap?: number;
  empty?: ReactNode;
  extraBottom?: number;
  bleedHeader?: boolean;
};

function useColumnCount(compact: boolean) {
  const { width } = useWindowDimensions();
  const base = width >= 760 ? 4 : width >= 520 ? 3 : 2;
  return compact ? Math.min(base + 1, 4) : base;
}

export function MasonryGrid({
  photos,
  onPressPhoto,
  onLongPressPhoto,
  selectionMode,
  selectedIds = [],
  favorites = [],
  showLabels = true,
  header,
  footer,
  padding = spacing.lg,
  gap = 10,
  empty,
  extraBottom = 0,
}: CommonProps) {
  const { settings } = useGallery();
  const { width } = useWindowDimensions();
  const columns = useColumnCount(settings.density === 'compact');
  const cardWidth = (width - padding * 2 - gap * (columns - 1)) / columns;
  const selected = useMemo(() => new Set(selectedIds), [selectedIds]);
  const favoriteSet = useMemo(() => new Set(favorites), [favorites]);

  const buckets = useMemo(() => {
    const cols: Array<Array<{ photo: Photo; height: number; index: number }>> = Array.from(
      { length: columns },
      () => []
    );
    const heights = new Array(columns).fill(0);
    photos.forEach((photo, index) => {
      const ratio = Math.max(0.72, Math.min(photo.height / photo.width, 1.55));
      const height = Math.round(cardWidth * ratio);
      const target = heights.indexOf(Math.min(...heights));
      cols[target].push({ photo, height, index });
      heights[target] += height + gap;
    });
    return cols;
  }, [photos, columns, cardWidth, gap]);

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 120 + extraBottom }}
    >
      {header}
      {photos.length === 0 ? (
        empty
      ) : (
        <View style={[styles.columns, { paddingHorizontal: padding, gap }]}>
          {buckets.map((bucket, colIndex) => (
            <View key={`col-${colIndex}`} style={{ flex: 1, gap }}>
              {bucket.map(({ photo, height, index }) => (
                <PhotoCard
                  key={photo.id}
                  photo={photo}
                  width={cardWidth}
                  height={height}
                  onPress={() => onPressPhoto(photo, index)}
                  onLongPress={onLongPressPhoto ? () => onLongPressPhoto(photo) : undefined}
                  selected={selected.has(photo.id)}
                  selectionMode={selectionMode}
                  favorite={favoriteSet.has(photo.id)}
                  showLabel={showLabels}
                />
              ))}
            </View>
          ))}
        </View>
      )}
      {footer}
    </ScrollView>
  );
}

export function PhotoGrid({
  photos,
  onPressPhoto,
  onLongPressPhoto,
  selectionMode,
  selectedIds = [],
  favorites = [],
  showLabels = false,
  header,
  footer,
  padding = spacing.lg,
  gap = 8,
  empty,
  extraBottom = 0,
  bleedHeader = false,
}: CommonProps) {
  const { settings } = useGallery();
  const { width } = useWindowDimensions();
  const columns = useColumnCount(settings.density === 'compact');
  const cardWidth = (width - padding * 2 - gap * (columns - 1)) / columns;
  const selected = useMemo(() => new Set(selectedIds), [selectedIds]);
  const favoriteSet = useMemo(() => new Set(favorites), [favorites]);

  return (
    <FlatList
      key={`grid-${columns}`}
      data={photos}
      keyExtractor={(item) => item.id}
      numColumns={columns}
      ListHeaderComponent={
        bleedHeader ? <View style={{ marginHorizontal: -padding }}>{header}</View> : <>{header}</>
      }
      ListFooterComponent={<>{footer}</>}
      ListEmptyComponent={<>{empty}</>}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: padding, paddingBottom: 120 + extraBottom, gap }}
      columnWrapperStyle={columns > 1 ? { gap } : undefined}
      renderItem={({ item, index }) => (
        <PhotoCard
          photo={item}
          width={cardWidth}
          height={cardWidth}
          onPress={() => onPressPhoto(item, index)}
          onLongPress={onLongPressPhoto ? () => onLongPressPhoto(item) : undefined}
          selected={selected.has(item.id)}
          selectionMode={selectionMode}
          favorite={favoriteSet.has(item.id)}
          showLabel={showLabels}
          radiusValue={12}
        />
      )}
    />
  );
}

const styles = StyleSheet.create({
  columns: { flexDirection: 'row', alignItems: 'flex-start' },
});
